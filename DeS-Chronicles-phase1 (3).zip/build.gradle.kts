plugins {
    java
}

group = "net.dragonempire"
version = "0.1.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // Pinned build. Bump deliberately; do not use floating ranges.
    compileOnly("io.papermc.paper:paper-api:26.2.build.65-beta")

    // Paper bundles sqlite-jdbc at runtime; tests need it on the classpath.
    testImplementation("org.xerial:sqlite-jdbc:3.46.1.3")
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.3")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher:1.11.3")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.test {
    useJUnitPlatform()
}

tasks.jar {
    archiveBaseName.set("DeS-Chronicles")
}
