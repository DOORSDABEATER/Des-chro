#!/usr/bin/env python3
"""Builds the DeS-Chronicles resource pack, or merges its assets into an existing pack folder.

  python3 tools/build_pack.py --format <N> [--out DeS-Chronicles-pack.zip]
  python3 tools/build_pack.py --merge /path/to/existing/pack          # copies assets/deschronicles only

<N> is the resource pack format of YOUR Minecraft version. It is deliberately not guessed here: look it up for 26.2
(the Minecraft Wiki lists them under "Pack format"). Only the `deschronicles` namespace is ever written, so an
existing pack (for example the shared DeS pack) is never overwritten.
"""
import argparse, hashlib, json, os, shutil, sys, zipfile

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'resourcepack')
NS = os.path.join(ROOT, 'assets', 'deschronicles')

def files():
    for d, _, fs in os.walk(NS):
        for f in sorted(fs):
            p = os.path.join(d, f)
            yield p, os.path.relpath(p, ROOT).replace(os.sep, '/')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--format', type=int, help='resource pack format number for your Minecraft version')
    ap.add_argument('--out', default='DeS-Chronicles-pack.zip')
    ap.add_argument('--merge', help='existing pack folder to copy assets/deschronicles into')
    a = ap.parse_args()
    if a.merge:
        dest = os.path.join(a.merge, 'assets', 'deschronicles')
        shutil.copytree(NS, dest, dirs_exist_ok=True)
        print('merged into', dest)
        return
    if not a.format:
        sys.exit('error: --format is required (the pack format number for your Minecraft version)')
    with zipfile.ZipFile(a.out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('pack.mcmeta', json.dumps({'pack': {'pack_format': a.format, 'description': 'DeS-Chronicles story assets'}}, indent=2))
        for p, arc in files():
            z.write(p, arc)
    print('wrote', a.out, 'sha1', hashlib.sha1(open(a.out, 'rb').read()).hexdigest())

if __name__ == '__main__':
    main()
