#!/usr/bin/env python3
"""Validates resourcepack/: JSON syntax, every referenced texture/sound/model exists, and only the deschronicles
namespace is used. Exit code 1 on problems. Run: python3 tools/validate_pack.py"""
import json, os, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'resourcepack', 'assets')
NS = 'deschronicles'
problems = []

def load(path):
    try:
        return json.load(open(path, encoding='utf-8'))
    except (OSError, ValueError) as e:
        problems.append(f'{path}: {e}')
        return None

def resource(kind, ref, ext):
    ns, _, p = ref.partition(':')
    if ns != NS:
        problems.append(f'{kind} {ref}: outside the {NS} namespace')
        return
    if not os.path.isfile(os.path.join(ROOT, ns, kind, p + ext)):
        problems.append(f'{kind} {ref}: file missing')

if os.listdir(ROOT) != [NS]:
    problems.append(f'assets/ must contain only "{NS}", found {os.listdir(ROOT)}')
sounds = load(os.path.join(ROOT, NS, 'sounds.json')) or {}
for event, spec in sounds.items():
    for s in spec.get('sounds', []):
        resource('sounds', s['name'] if isinstance(s, dict) else s, '.ogg')
for f in sorted(os.listdir(os.path.join(ROOT, NS, 'items'))):
    d = load(os.path.join(ROOT, NS, 'items', f))
    if d: resource('models', d['model']['model'], '.json')
for f in sorted(os.listdir(os.path.join(ROOT, NS, 'models', 'item'))):
    d = load(os.path.join(ROOT, NS, 'models', 'item', f))
    if d:
        for tex in d.get('textures', {}).values(): resource('textures', tex, '.png')
for f in sorted(os.listdir(os.path.join(ROOT, NS, 'textures', 'item'))):
    sig = open(os.path.join(ROOT, NS, 'textures', 'item', f), 'rb').read(8)
    if sig != b'\x89PNG\r\n\x1a\n': problems.append(f'texture {f}: not a PNG')
for f in sorted(os.listdir(os.path.join(ROOT, NS, 'sounds'))):
    if open(os.path.join(ROOT, NS, 'sounds', f), 'rb').read(4) != b'OggS': problems.append(f'sound {f}: not an Ogg file')
print('OK: resource pack is consistent' if not problems else '\n'.join(problems))
sys.exit(1 if problems else 0)
