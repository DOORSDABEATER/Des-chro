package net.dragonempire.chronicles;

import net.dragonempire.chronicles.condition.ConditionContext;

import java.util.HashSet;
import java.util.Set;

final class FakeContext implements ConditionContext {
    final Set<String> completed = new HashSet<>(), active = new HashSet<>(), perms = new HashSet<>(),
            choices = new HashSet<>(), items = new HashSet<>();
    int level = 1;

    public boolean hasCompletedQuest(String q) { return completed.contains(q); }
    public boolean hasActiveQuest(String q) { return active.contains(q); }
    public boolean hasItem(String m, int a) { return items.contains(m); }
    public boolean hasPermission(String n) { return perms.contains(n); }
    public int level() { return level; }
    public boolean hasAchievement(String id) { return false; }
    public boolean hasVisited(String l) { return false; }
    public boolean hasDefeatedBoss(String b) { return false; }
    public boolean choseOption(String d, String c) { return choices.contains(d + ":" + c); }
    public boolean atQuestlineStage(String l, String s) { return false; }
    final Set<String> events = new HashSet<>();
    public boolean eventActive(String e) { return events.contains(e); }
    final java.util.Map<String, Integer> counters = new java.util.HashMap<>();
    final java.util.Map<String, Long> globals = new java.util.HashMap<>();
    public int counter(String k) { return counters.getOrDefault(k, 0); }
    public boolean globalAtLeast(String k, long min) { return globals.getOrDefault(k, 0L) >= min; }
}
