package net.dragonempire.chronicles;

import net.dragonempire.chronicles.bosses.BossParser;
import net.dragonempire.chronicles.parties.PartyManager;
import net.dragonempire.chronicles.procedural.ProceduralGenerator;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZoneId;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ProceduralPartyBossTest {
    private Map<String, Object> template() {
        Map<String, Object> t = new LinkedHashMap<>();
        t.put("rotation", "daily");
        t.put("title", "Daily Hunt: {amount} {target}");
        t.put("description", "Defeat {amount} {target}.");
        t.put("pool", List.of(
                Map.of("type", "KILL_MOB", "targets", List.of("ZOMBIE", "SKELETON", "SPIDER"), "amount", Map.of("min", 10, "max", 20)),
                Map.of("type", "COLLECT_ITEM", "target", "IRON_INGOT", "amount", 32)));
        t.put("tiers", List.of(Map.of("min_level", 0, "max_level", 20, "multiplier", 1.0),
                Map.of("min_level", 20, "multiplier", 2.0, "rewards", List.of(Map.of("type", "xp", "amount", 99)))));
        t.put("rewards", List.of(Map.of("type", "xp", "amount", 10)));
        return t;
    }

    @Test
    void generationIsDeterministicPerPeriodAndTiersScale() {
        List<ValidationIssue> issues = new ArrayList<>();
        var a = ProceduralGenerator.generate("hunt", template(), "20261114", "hunt.yml", issues);
        var b = ProceduralGenerator.generate("hunt", template(), "20261114", "hunt.yml", issues);
        assertTrue(issues.isEmpty(), issues.toString());
        assertEquals(a, b);                                              // same day, same quest
        assertEquals(2, a.size());
        assertEquals("proc_hunt_20261114_t1", a.get(0).get("id"));
        assertEquals(20, a.get(1).get("required_level"));
        @SuppressWarnings("unchecked")
        int low = (Integer) ((Map<String, Object>) ((List<?>) a.get(0).get("objectives")).get(0)).get("amount");
        @SuppressWarnings("unchecked")
        int high = (Integer) ((Map<String, Object>) ((List<?>) a.get(1).get("objectives")).get(0)).get("amount");
        assertEquals(Math.max(1, Math.round(low * 2.0f)), high);          // tier 2 doubles the amount
        assertNotEquals(a.get(0).get("rewards"), a.get(1).get("rewards")); // tier-specific rewards
        assertEquals("published", a.get(0).get("status"));
    }

    @Test
    void differentDaysEventuallyDiffer() {
        Set<Object> seen = new HashSet<>();
        for (int d = 1; d <= 20; d++) {
            var q = ProceduralGenerator.generate("hunt", template(), String.format("202611%02d", d), "h", new ArrayList<>());
            seen.add(q.get(0).get("title"));
        }
        assertTrue(seen.size() > 3, "rotation should vary across days: " + seen);
    }

    @Test
    void periodKeysFollowResetBoundaries() {
        ZoneId utc = ZoneId.of("UTC");
        assertEquals("20261112", ProceduralGenerator.periodKey("daily", Instant.parse("2026-11-12T23:59:00Z"), utc));
        assertEquals("20261113", ProceduralGenerator.periodKey("daily", Instant.parse("2026-11-13T00:00:00Z"), utc));
        assertEquals("20261109", ProceduralGenerator.periodKey("weekly", Instant.parse("2026-11-12T10:00:00Z"), utc)); // Monday
    }

    @Test
    void invalidTemplatesReportProblems() {
        List<ValidationIssue> issues = new ArrayList<>();
        assertTrue(ProceduralGenerator.generate("x", Map.of("title", "t", "pool", List.of()), "k", "x.yml", issues).isEmpty());
        issues.clear();
        assertTrue(ProceduralGenerator.generate("x", Map.of("title", "t", "rotation", "monthly",
                "pool", List.of(Map.of("type", "KILL_MOB", "amount", 0))), "k", "x.yml", issues).isEmpty());
        assertEquals(2, issues.size());
    }

    @Test
    void partiesPersistAndRestore() {
        PartyManager pm = new PartyManager(4);
        int[] changes = {0};
        pm.setOnChange(() -> changes[0]++);
        UUID a = UUID.randomUUID(), b = UUID.randomUUID(), c = UUID.randomUUID();
        pm.create(a);
        pm.invite(a, b, 0);
        pm.accept(b, 1);
        pm.invite(a, c, 0);
        pm.accept(c, 1);
        assertEquals(3, changes[0]);
        var snap = pm.snapshot();
        assertEquals(List.of(a, b, c), snap.get(a));

        PartyManager fresh = new PartyManager(4);
        fresh.restore(snap);
        assertEquals(3, fresh.membersOf(b).size());
        assertTrue(fresh.inParty(c));
        assertNull(fresh.invite(a, UUID.randomUUID(), 0));      // leader is restored as leader
        Map<UUID, List<UUID>> bad = new LinkedHashMap<>();
        bad.put(a, List.of(b));
        bad.put(c, List.of(b, a));                              // conflicts with the first party: skipped
        PartyManager conflict = new PartyManager(4);
        conflict.restore(bad);
        assertEquals(2, conflict.membersOf(a).size());
        assertFalse(conflict.inParty(c));
    }

    @Test
    void bossCanBeExternal() {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("location", Map.of("world", "w", "x", 1, "y", 2, "z", 3));
        root.put("external", Map.of("spawn_command", "mm mobs spawn Guardian 1 {world},{x},{y},{z}", "mythic", "Guardian"));
        List<ValidationIssue> issues = new ArrayList<>();
        var b = BossParser.parse("g", root, "g.yml", Set.of(), issues);
        assertNotNull(b, issues.toString());
        assertEquals("Guardian", b.mythic());
        issues.clear();
        assertNull(BossParser.parse("g", Map.of("location", Map.of("world", "w", "x", 1, "y", 2, "z", 3)), "g.yml", Set.of(), issues));
        assertFalse(issues.isEmpty());                           // neither entity nor external
    }
}
