package net.dragonempire.chronicles;

import net.dragonempire.chronicles.npc.NpcNames;
import net.dragonempire.chronicles.npc.SkinSpec;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class NpcNamesSkinTest {
    @Test
    void idsAreNormalisedAndNamesPrettified() {
        assertEquals("ancient_one", NpcNames.normalizeId("Ancient One"));
        assertEquals("ancient_one", NpcNames.normalizeId("  Ancient-One "));
        assertEquals("the_old_man", NpcNames.normalizeId("The  Old__Man!"));
        assertTrue(NpcNames.validId("ancient_one"));
        assertFalse(NpcNames.validId("a"));
        assertFalse(NpcNames.validId("Ancient"));
        assertEquals("Ancient One", NpcNames.prettify("ancient_one"));
        assertEquals("Guard 2", NpcNames.prettify("guard_2"));
        assertEquals("", NpcNames.prettify("__"));
    }

    @Test
    void skinByPlayerOrTexture() {
        List<ValidationIssue> issues = new ArrayList<>();
        SkinSpec byName = SkinSpec.parse(Map.of("player", "Notch"), "n.yml", "skin", issues);
        assertTrue(byName.byPlayer());
        assertEquals("{immovable:1b,hide_description:1b,profile:{name:\"Notch\"}}", byName.toNbt());
        SkinSpec tex = SkinSpec.parse(Map.of("value", "eyJ0ZXh0dXJlcyI6e319", "signature", "c2lnbmF0dXJl"), "n.yml", "skin", issues);
        assertFalse(tex.byPlayer());
        assertTrue(tex.toNbt().contains("name:\"textures\",value:\"eyJ0ZXh0dXJlcyI6e319\",signature:\"c2lnbmF0dXJl\""));
        SkinSpec unsigned = SkinSpec.parse(Map.of("value", "eyJ0ZXh0dXJlcyI6e319"), "n.yml", "skin", issues);
        assertFalse(unsigned.toNbt().contains("signature"));
        assertTrue(issues.isEmpty());
        assertNull(SkinSpec.parse(null, "n.yml", "skin", issues));                 // absent is fine
        assertTrue(issues.isEmpty());
    }

    @Test
    void skinInputsCannotInjectCommands() {
        List<ValidationIssue> issues = new ArrayList<>();
        assertNull(SkinSpec.parse(Map.of("player", "x\"} run stop"), "n.yml", "skin", issues));
        assertNull(SkinSpec.parse(Map.of("value", "abc\"def;stop"), "n.yml", "skin", issues));
        assertNull(SkinSpec.parse(Map.of("value", "eyJ0ZXh0dXJlcyI6e319", "signature", "bad sig;"), "n.yml", "skin", issues));
        assertNull(SkinSpec.parse(Map.of(), "n.yml", "skin", issues));
        assertNull(SkinSpec.parse("string", "n.yml", "skin", issues));
        assertEquals(5, issues.size());
    }
}
