package net.dragonempire.chronicles;

import net.dragonempire.chronicles.achievements.AchievementParser;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class AchievementParserTest {
    @Test
    void parsesAndRejects() {
        Map<String, Object> entries = new LinkedHashMap<>();
        entries.put("good_one", Map.of("title", "Good", "description", "d", "hidden", true));
        entries.put("Bad Id", Map.of("title", "x"));
        entries.put("no_title", Map.of("description", "d"));
        List<ValidationIssue> issues = new ArrayList<>();
        var out = AchievementParser.parse(Map.of("achievements", entries), "achievements.yml", issues);
        assertEquals(1, out.size());
        assertTrue(out.get("good_one").hidden());
        assertEquals(2, issues.size());
    }
}
