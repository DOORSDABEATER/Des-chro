package net.dragonempire.chronicles;

import net.dragonempire.chronicles.validation.DependencyGraph;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DependencyGraphTest {
    @Test
    void acyclicGraphHasNoCycle() {
        DependencyGraph g = new DependencyGraph();
        g.addPrerequisite("b", "a");
        g.addPrerequisite("c", "b");
        g.addPrerequisite("c", "a");
        assertTrue(g.findCycle().isEmpty());
    }

    @Test
    void detectsCycle() {
        DependencyGraph g = new DependencyGraph();
        g.addPrerequisite("a", "c");
        g.addPrerequisite("b", "a");
        g.addPrerequisite("c", "b");
        var cycle = g.findCycle();
        assertTrue(cycle.isPresent());
        assertEquals(cycle.get().getFirst(), cycle.get().getLast());
    }

    @Test
    void detectsSelfLoop() {
        DependencyGraph g = new DependencyGraph();
        g.addPrerequisite("a", "a");
        assertTrue(g.findCycle().isPresent());
    }
}
