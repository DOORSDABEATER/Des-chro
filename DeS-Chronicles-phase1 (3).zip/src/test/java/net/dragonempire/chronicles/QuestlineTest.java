package net.dragonempire.chronicles;

import net.dragonempire.chronicles.questline.*;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class QuestlineTest {
    private static final Set<String> QUESTS = Set.of("a", "b", "c", "d", "end1", "end2");
    private static final Set<String> RT = Set.of("xp", "item");

    private static Map<String, Object> ch(String id, List<String> quests, List<String> requires) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id); m.put("quests", quests); m.put("requires", requires);
        return m;
    }

    private Questline line() {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("title", "L");
        root.put("chapters", List.of(
                ch("one", List.of("a"), List.of()),
                ch("two", List.of("b", "c"), List.of("one")),
                ch("three", List.of("end1", "end2"), List.of("two"))));
        root.put("endings", List.of("end1", "end2"));
        List<ValidationIssue> issues = new ArrayList<>();
        Questline l = QuestlineParser.parse("L", root, "l.yml", QUESTS, RT, issues);
        assertNotNull(l, issues.toString());
        return l;
    }

    @Test
    void chaptersUnlockInOrderAndBranchEndingCompletes() {
        Questline l = line();
        Set<String> done = new HashSet<>();
        var e = QuestlineProgress.evaluate(l, done::contains);
        assertEquals(QuestlineProgress.Status.AVAILABLE, e.chapters().get("one"));
        assertEquals(QuestlineProgress.Status.LOCKED, e.chapters().get("two"));
        assertFalse(QuestlineProgress.questUnlocked(l, "b", e));

        done.add("a");
        e = QuestlineProgress.evaluate(l, done::contains);
        assertEquals(QuestlineProgress.Status.COMPLETE, e.chapters().get("one"));
        assertEquals(QuestlineProgress.Status.AVAILABLE, e.chapters().get("two"));
        assertTrue(QuestlineProgress.questUnlocked(l, "b", e));

        done.addAll(List.of("b", "c"));
        e = QuestlineProgress.evaluate(l, done::contains);
        assertFalse(e.complete());                     // needs an ending
        done.add("end2");                              // either ending finishes the third chapter's requirement of both? no: chapter needs both
        e = QuestlineProgress.evaluate(l, done::contains);
        assertEquals("end2", e.endingQuest());
        assertEquals(QuestlineProgress.Status.AVAILABLE, e.chapters().get("three")); // required = all quests of the chapter
    }

    @Test
    void chapterRequiredCountAllowsAlternativeRoutes() {
        Map<String, Object> c = ch("route", List.of("end1", "end2"), List.of());
        c.put("required", 1);
        Map<String, Object> root = Map.of("title", "L", "chapters", List.of(c), "endings", List.of("end1", "end2"));
        Questline l = QuestlineParser.parse("L", root, "l.yml", QUESTS, RT, new ArrayList<>());
        var e = QuestlineProgress.evaluate(l, "end2"::equals);
        assertTrue(e.complete());
        assertEquals("end2", e.endingQuest());
    }

    @Test
    void parserRejectsCyclesUnknownQuestsAndBadRequired() {
        List<ValidationIssue> issues = new ArrayList<>();
        assertNull(QuestlineParser.parse("L", Map.of("title", "L", "chapters", List.of(
                ch("x", List.of("a"), List.of("y")), ch("y", List.of("b"), List.of("x")))), "l.yml", QUESTS, RT, issues));
        assertTrue(issues.stream().anyMatch(i -> i.message().contains("circular")));
        issues.clear();
        assertNull(QuestlineParser.parse("L", Map.of("title", "L", "chapters", List.of(ch("x", List.of("nope"), List.of()))),
                "l.yml", QUESTS, RT, issues));
        assertTrue(issues.stream().anyMatch(i -> i.message().contains("unknown quest 'nope'")));
    }
}
