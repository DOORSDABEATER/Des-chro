package net.dragonempire.chronicles;

import net.dragonempire.chronicles.dialogue.*;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class DialogueTest {
    private static final Set<String> ACTIONS = Set.of("start_quest", "set_flag");

    private Map<String, Object> doc() {
        Map<String, Object> nodes = new LinkedHashMap<>();
        nodes.put("greeting", Map.of(
                "pages", List.of("After all this time...", "you finally returned."),
                "choices", List.of(
                        Map.of("id", "world", "text", "What happened?", "next", "world"),
                        Map.of("id", "help", "text", "I need help.", "next", "end",
                                "if", Map.of("type", "completed_quest", "quest", "q1"),
                                "actions", List.of(Map.of("type", "start_quest", "quest", "q2"))),
                        Map.of("id", "bye", "text", "Nothing.", "next", "end"))));
        nodes.put("world", Map.of("pages", List.of("It fell."), "choices", List.of()));
        nodes.put("returning", Map.of("pages", List.of("Welcome back, hero.")));
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("speaker", "The Ancient One");
        root.put("start", "greeting");
        root.put("start_variants", List.of(Map.of("node", "returning",
                "if", Map.of("type", "completed_quest", "quest", "q2"))));
        root.put("nodes", nodes);
        return root;
    }

    @Test
    void walksPagesChoicesAndConditions() {
        List<ValidationIssue> issues = new ArrayList<>();
        var def = DialogueParser.parse("d", doc(), "d.yml", ACTIONS, issues);
        assertNotNull(def);
        assertTrue(issues.isEmpty());

        FakeContext ctx = new FakeContext();
        var s = new DialogueSession(def, ctx);
        assertTrue(s.hasMorePages());
        assertTrue(s.visibleChoices().isEmpty());          // choices hidden until last page
        s.advance();
        assertEquals(2, s.visibleChoices().size());          // "help" gated by condition
        ctx.completed.add("q1");
        assertEquals(3, s.visibleChoices().size());

        var r = s.choose(1);                                 // help
        assertTrue(r.ended());
        assertEquals("start_quest", r.actions().get(0).type());
        assertEquals(List.of("help"), s.history());
    }

    @Test
    void branchesAndEndsOnChoicelessNode() {
        var def = DialogueParser.parse("d", doc(), "d.yml", ACTIONS, new ArrayList<>());
        var s = new DialogueSession(def, new FakeContext());
        s.advance();
        s.choose(0);                                         // -> world
        assertEquals("world", s.node().id());
        assertFalse(s.ended());
        s.advance();
        assertTrue(s.ended());
    }

    @Test
    void startVariantChangesDialogueAfterQuest() {
        var def = DialogueParser.parse("d", doc(), "d.yml", ACTIONS, new ArrayList<>());
        FakeContext ctx = new FakeContext();
        ctx.completed.add("q2");
        assertEquals("returning", new DialogueSession(def, ctx).node().id());
    }

    @Test
    void invalidChoiceIndexRejected() {
        var def = DialogueParser.parse("d", doc(), "d.yml", ACTIONS, new ArrayList<>());
        var s = new DialogueSession(def, new FakeContext());
        s.advance();
        assertThrows(IllegalArgumentException.class, () -> s.choose(2)); // gated choice not visible
    }

    @Test
    void validationCatchesBrokenReferencesAndUnknownActions() {
        Map<String, Object> d = doc();
        @SuppressWarnings("unchecked")
        Map<String, Object> nodes = (Map<String, Object>) d.get("nodes");
        nodes.put("bad", Map.of("pages", List.of("x"), "choices", List.of(
                Map.of("id", "c", "text", "t", "next", "missing",
                        "actions", List.of(Map.of("type", "format_disk"))))));
        List<ValidationIssue> issues = new ArrayList<>();
        assertNull(DialogueParser.parse("d", d, "d.yml", ACTIONS, issues));
        assertTrue(issues.stream().anyMatch(i -> i.message().contains("unknown node 'missing'")));
        assertTrue(issues.stream().anyMatch(i -> i.message().contains("unknown action 'format_disk'")));
    }
}
