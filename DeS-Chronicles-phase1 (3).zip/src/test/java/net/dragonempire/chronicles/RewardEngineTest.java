package net.dragonempire.chronicles;

import net.dragonempire.chronicles.rewards.*;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.random.RandomGenerator;

import static org.junit.jupiter.api.Assertions.*;

class RewardEngineTest {
    static final class MemStore implements ClaimStore {
        final Set<String> claimed = new HashSet<>();
        public CompletableFuture<Boolean> claimReward(UUID p, String q, String k) {
            return CompletableFuture.completedFuture(claimed.add(p + "|" + q + "|" + k));
        }
    }

    private static final Set<String> TYPES = Set.of("item", "money", "xp");

    @Test
    void secondAwardGrantsNothing() {
        List<ValidationIssue> issues = new ArrayList<>();
        var specs = RewardParser.parse(List.of(Map.of("type", "xp", "key", "xp1"), Map.of("type", "money", "key", "m1")),
                "q.yml", "rewards", TYPES, issues);
        assertTrue(issues.isEmpty());
        List<String> granted = new ArrayList<>();
        var engine = new RewardEngine(new MemStore(), (p, r) -> granted.add(r.key()), Runnable::run, RandomGenerator.getDefault());
        UUID p = UUID.randomUUID();
        assertEquals(2, engine.award(p, "q", specs).join());
        assertEquals(0, engine.award(p, "q", specs).join());
        assertEquals(List.of("xp1", "m1"), granted);
    }

    @Test
    void chanceIsRespected() {
        var specs = List.of(new RewardSpec("rare", "item", Map.of(), 0.25));
        var never = new RewardEngine(new MemStore(), (p, r) -> fail("granted"), Runnable::run, new FixedRandom(0.9));
        assertEquals(0, never.award(UUID.randomUUID(), "q", specs).join());
        List<String> got = new ArrayList<>();
        var always = new RewardEngine(new MemStore(), (p, r) -> got.add(r.key()), Runnable::run, new FixedRandom(0.1));
        assertEquals(1, always.award(UUID.randomUUID(), "q", specs).join());
    }

    @Test
    void parserRejectsUnknownTypeBadChanceAndDuplicateKey() {
        List<ValidationIssue> issues = new ArrayList<>();
        RewardParser.parse(List.of(Map.of("type", "exec"), Map.of("type", "xp", "chance", 2.0),
                Map.of("type", "xp", "key", "k"), Map.of("type", "xp", "key", "k")), "q.yml", "rewards", TYPES, issues);
        assertEquals(3, issues.size());
    }

    record FixedRandom(double v) implements RandomGenerator {
        public long nextLong() { return 0; }
        public double nextDouble() { return v; }
    }
}
