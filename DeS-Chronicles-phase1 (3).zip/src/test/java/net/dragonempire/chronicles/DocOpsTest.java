package net.dragonempire.chronicles;

import net.dragonempire.chronicles.objectives.QuestPlan;
import net.dragonempire.chronicles.objectives.QuestPlanParser;
import net.dragonempire.chronicles.studio.DocOps;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class DocOpsTest {
    private static Map<String, Object> obj(String id, String type) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id); m.put("type", type); m.put("target", "x"); m.put("amount", 1);
        return m;
    }

    @Test
    void flatObjectivesBecomeOneSequentialStageThenGrow() {
        List<Map<String, Object>> flat = List.of(obj("o1", "TALK_NPC"));
        List<Map<String, Object>> stages = DocOps.stagesOf(List.of(), flat);
        assertEquals(1, stages.size());
        assertEquals("sequential", stages.get(0).get("mode"));
        assertEquals("o2", DocOps.nextObjectiveId(stages));
        assertNull(DocOps.addObjective(stages, 1, obj("o2", "KILL_MOB")));
        stages.add(DocOps.newStage("parallel", obj(DocOps.nextObjectiveId(stages), "COLLECT_ITEM")));
        assertEquals(2, stages.size());
        assertNotNull(DocOps.addObjective(stages, 5, obj("o9", "X")));
        assertNull(DocOps.addObjective(stages, 0, obj("o4", "KILL_MOB")));       // 0 = last stage
        // the result is a valid plan for the real parser
        List<ValidationIssue> issues = new ArrayList<>();
        QuestPlan plan = QuestPlanParser.parse(Map.of("stages", stages), "q.yml", issues);
        assertNotNull(plan, issues.toString());
        assertEquals(2, plan.stages().size());
        assertEquals(2, plan.stages().get(0).objectives().size());
        assertEquals(2, plan.stages().get(1).objectives().size());
    }

    @Test
    void existingStagesAreCopiedNotShared() {
        List<Map<String, Object>> original = new ArrayList<>();
        Map<String, Object> st = new LinkedHashMap<>();
        st.put("mode", "parallel");
        st.put("objectives", new ArrayList<>(List.of(obj("a", "T"))));
        original.add(st);
        List<Map<String, Object>> copy = DocOps.stagesOf(original, null);
        DocOps.addObjective(copy, 1, obj("b", "T"));
        assertEquals(1, ((List<?>) original.get(0).get("objectives")).size());   // original untouched
        assertEquals("parallel", copy.get(0).get("mode"));
    }

    @Test
    void choiceConditionsAndActionsAppend() {
        List<Map<String, Object>> choices = DocOps.choicesOf(List.of(
                new LinkedHashMap<>(Map.of("id", "a", "text", "A", "next", "end", "if", Map.of("type", "level", "min", 5))),
                new LinkedHashMap<>(Map.of("id", "b", "text", "B", "next", "end"))));
        Map<String, Object> out = new LinkedHashMap<>();
        assertNull(DocOps.addToChoice(choices, "a", "if", DocOps.typed("completed_quest", List.of("quest=q1")), out));
        assertEquals(2, ((List<?>) out.get("if")).size());                       // single map promoted to a list (AND)
        assertNull(DocOps.addToChoice(choices, "b", "actions", DocOps.typed("add_counter", List.of("key=rep", "amount=3")), new LinkedHashMap<>()));
        assertNotNull(DocOps.addToChoice(choices, "zzz", "if", Map.of(), new LinkedHashMap<>()));
    }

    @Test
    void typedParsesTokens() {
        var m = DocOps.typed("item", List.of("item=DIAMOND", "amount=2", "chance=0.5", "flag=true"));
        assertEquals(2, m.get("amount"));
        assertEquals(0.5, m.get("chance"));
        assertEquals(true, m.get("flag"));
        assertNull(DocOps.typed("item", List.of("broken")));
    }
}
