package net.dragonempire.chronicles;

import net.dragonempire.chronicles.community.GoalParser;
import net.dragonempire.chronicles.condition.ConditionParser;
import net.dragonempire.chronicles.interactions.*;
import net.dragonempire.chronicles.objectives.*;
import net.dragonempire.chronicles.quest.QuestFiles;
import net.dragonempire.chronicles.quest.QuestStatus;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class FeatureLogicTest {
    @Test
    void counterAndGlobalConditions() {
        FakeContext ctx = new FakeContext();
        List<ValidationIssue> issues = new ArrayList<>();
        var rep = ConditionParser.parse(Map.of("type", "counter", "key", "rep:archivists", "min", 5, "max", 9), "f", "if", issues);
        var glob = ConditionParser.parse(Map.of("type", "global", "key", "snow", "min", 100), "f", "if", issues);
        assertTrue(issues.isEmpty());
        assertFalse(rep.test(ctx));
        ctx.counters.put("rep:archivists", 6);
        assertTrue(rep.test(ctx));
        ctx.counters.put("rep:archivists", 12);
        assertFalse(rep.test(ctx));                     // above max
        assertFalse(glob.test(ctx));
        ctx.globals.put("snow", 150L);
        assertTrue(glob.test(ctx));
        ConditionParser.parse(Map.of("type", "counter", "key", "x"), "f", "if", issues);   // neither min nor max
        assertEquals(1, issues.size());
    }

    @Test
    void resetOnDeathZeroesOnlyUnfinishedMarkedObjectives() {
        Map<String, Object> obj = new LinkedHashMap<>();
        obj.put("id", "alive"); obj.put("type", "SURVIVE"); obj.put("amount", 60); obj.put("reset_on_death", true);
        Map<String, Object> other = new LinkedHashMap<>();
        other.put("id", "kills"); other.put("type", "KILL_MOB"); other.put("target", "ZOMBIE"); other.put("amount", 5);
        List<ValidationIssue> issues = new ArrayList<>();
        QuestPlan plan = QuestPlanParser.parse(Map.of("stages", List.of(Map.of("mode", "parallel", "objectives", List.of(obj, other)))), "q", issues);
        assertNotNull(plan, issues.toString());
        QuestProgress p = new QuestProgress();
        p.apply(plan, new ObjectiveEvent("SURVIVE", "any", 30));
        p.apply(plan, new ObjectiveEvent("KILL_MOB", "ZOMBIE", 2));
        assertTrue(p.resetOnDeath(plan));
        assertEquals(0, p.count("alive"));
        assertEquals(2, p.count("kills"));
        assertFalse(p.resetOnDeath(plan));              // nothing left to reset
    }

    @Test
    void puzzleNeedsExactOrderAndWrongStepRestarts() {
        PuzzleDefinition pz = new PuzzleDefinition("runes", List.of("a", "b", "c"));
        PuzzleTracker t = new PuzzleTracker();
        UUID u = UUID.randomUUID();
        assertEquals(PuzzleTracker.Result.PROGRESS, t.advance(u, pz, "a"));
        assertEquals(PuzzleTracker.Result.WRONG, t.advance(u, pz, "c"));
        assertEquals(PuzzleTracker.Result.PROGRESS, t.advance(u, pz, "a"));
        assertEquals(PuzzleTracker.Result.PROGRESS, t.advance(u, pz, "b"));
        assertEquals(PuzzleTracker.Result.SOLVED, t.advance(u, pz, "c"));
        assertEquals(PuzzleTracker.Result.PROGRESS, t.advance(u, pz, "a"));   // restarts cleanly after solving
        assertEquals(PuzzleTracker.Result.WRONG, t.advance(UUID.randomUUID(), pz, "b")); // other players are independent
    }

    @Test
    void interactionParserValidates() {
        Map<String, Object> items = new LinkedHashMap<>();
        items.put("a", Map.of("world", "w", "x", 1, "y", 2, "z", 3, "event", "activate_ritual"));
        items.put("dup", Map.of("world", "w", "x", 1, "y", 2, "z", 3));
        items.put("off", Map.of("enabled", false));
        items.put("bad", Map.of("world", "w", "x", 1, "y", 2, "z", 4, "event", "no way!"));
        Map<String, Object> puzzles = Map.of("p", Map.of("steps", List.of("a")));
        List<ValidationIssue> issues = new ArrayList<>();
        var r = InteractionParser.parse(Map.of("interactables", items, "puzzles", puzzles), "i.yml", issues);
        assertEquals(1, r.interactables().size());
        assertEquals("ACTIVATE_RITUAL", r.interactables().get("a").event());
        assertEquals(3, issues.size());                 // duplicate block, bad event, too-short puzzle
    }

    @Test
    void goalParser() {
        List<ValidationIssue> issues = new ArrayList<>();
        var out = GoalParser.parse(Map.of("goals", Map.of(
                "snow", Map.of("title", "Snow", "key", "snow", "target", 500),
                "bad", Map.of("title", "x"))), "community.yml", issues);
        assertEquals(1, out.size());
        assertEquals(500L, out.get("snow").target());
        assertEquals(2, issues.size());
    }

    @Test
    void questFileStatusEditKeepsEverythingElse() {
        String yaml = "# header comment\ntitle: \"X\"\nstatus: draft   # keep me out\ndescription: d\n";
        String out = QuestFiles.setStatusText(yaml, QuestStatus.PUBLISHED);
        assertTrue(out.contains("status: published"));
        assertTrue(out.contains("# header comment") && out.contains("title: \"X\"") && out.contains("description: d"));
        assertEquals(QuestStatus.PUBLISHED, QuestFiles.readStatus(out));
        assertEquals(QuestStatus.DISABLED, QuestFiles.readStatus("status: \"disabled\" # x\n"));
        assertTrue(QuestFiles.setStatusText("title: x\n", QuestStatus.DISABLED).startsWith("status: disabled"));
    }
}
