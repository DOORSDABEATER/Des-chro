package net.dragonempire.chronicles;

import net.dragonempire.chronicles.storage.Database;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class DatabaseTest {
    @TempDir Path tmp;

    @Test
    void rewardCanOnlyBeClaimedOnce() {
        UUID p = UUID.randomUUID();
        try (Database db = new Database(tmp.resolve("t.db"))) {
            db.open().join();
            assertTrue(db.claimReward(p, "q1", "first_clear").join());
            assertFalse(db.claimReward(p, "q1", "first_clear").join());
            assertTrue(db.claimReward(p, "q1", "bonus").join());
        }
    }

    @Test
    void completionsPersistAcrossReopenAndMigrationIsIdempotent() {
        UUID p = UUID.randomUUID();
        Path file = tmp.resolve("persist.db");
        try (Database db = new Database(file)) {
            db.open().join();
            db.recordCompletion(p, "q1").join();
            db.recordCompletion(p, "q1").join();
        }
        try (Database db = new Database(file)) {
            db.open().join();
            assertEquals(2, db.completionCount(p, "q1").join());
            assertEquals(4, db.schemaVersion().join());
        }
    }

    @Test
    void playerStateRoundTripsAndResetClearsEverything() {
        UUID p = UUID.randomUUID();
        try (Database db = new Database(tmp.resolve("state.db"))) {
            db.open().join();
            db.saveQuest(p, "q1", "0;0;a=1").join();
            db.saveQuest(p, "q1", "0;0;a=2").join();
            db.addFlag(p, "visited:ruins").join();
            db.addFlag(p, "visited:ruins").join();
            db.recordCompletion(p, "q2").join();
            db.claimReward(p, "q2#1", "r0").join();

            var data = db.loadPlayer(p).join();
            assertEquals("0;0;a=2", data.activeQuests().get("q1"));
            assertEquals(1, data.flags().size());
            assertEquals(1, data.completions().get("q2"));
            assertTrue(data.lastCompleted().get("q2") > 0);
            db.setCounter(p, "rep:archivists", 3).join();
            db.setCounter(p, "rep:archivists", 7).join();
            assertEquals(7, db.loadPlayer(p).join().counters().get("rep:archivists"));
            db.recordCompletion(UUID.randomUUID(), "q2").join();
            assertEquals(2, db.topCompletions("q2", 10).join().size());
            db.setServerState("event:winter", "on").join();
            db.setServerState("event:winter", "off").join();
            assertEquals("off", db.loadServerState().join().get("event:winter"));

            db.resetQuest(p, "q2").join();
            assertEquals(0, db.loadPlayer(p).join().completions().size());
            assertTrue(db.claimReward(p, "q2#1", "r0").join()); // claim row was cleared too

            db.removeFlag(p, "visited:ruins").join();
            db.deleteQuest(p, "q1").join();
            var after = db.loadPlayer(p).join();
            assertTrue(after.flags().isEmpty());
            assertTrue(after.activeQuests().isEmpty());
        }
    }
}
