package net.dragonempire.chronicles;

import net.dragonempire.chronicles.objectives.CraftMath;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CraftMathTest {
    @Test
    void singleClickIsOneCraft() {
        assertEquals(4, CraftMath.produced(false, new int[]{64, 64, 0}, 4));
        assertEquals(1, CraftMath.produced(false, new int[]{3}, 0));   // result amount below 1 counts as 1
    }

    @Test
    void shiftClickUsesSmallestIngredientStack() {
        assertEquals(10 * 4, CraftMath.produced(true, new int[]{64, 10, 0, 33}, 4));
        assertEquals(64, CraftMath.produced(true, new int[]{64, 64}, 1));
        assertEquals(2, CraftMath.produced(true, new int[]{0, 0}, 2));  // empty grid falls back to one craft
    }
}
