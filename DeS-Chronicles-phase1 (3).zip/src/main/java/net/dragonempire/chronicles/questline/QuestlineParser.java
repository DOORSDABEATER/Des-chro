package net.dragonempire.chronicles.questline;

import net.dragonempire.chronicles.rewards.RewardParser;
import net.dragonempire.chronicles.rewards.RewardSpec;
import net.dragonempire.chronicles.validation.DependencyGraph;
import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class QuestlineParser {
    private QuestlineParser() {}

    public static Questline parse(String id, Map<String, Object> root, String file, Set<String> knownQuests,
                                  Set<String> rewardTypes, List<ValidationIssue> issues) {
        int before = issues.size();
        String title = root.get("title") instanceof String s && !s.isBlank() ? s : null;
        if (title == null) issues.add(new ValidationIssue(file, "title", "required"));
        if (!(root.get("chapters") instanceof List<?> raw) || raw.isEmpty()) {
            issues.add(new ValidationIssue(file, "chapters", "at least one chapter required"));
            return null;
        }
        List<Chapter> chapters = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        List<Map<?, ?>> maps = new ArrayList<>();
        for (int i = 0; i < raw.size(); i++) {
            String p = "chapters[" + i + "]";
            if (!(raw.get(i) instanceof Map<?, ?> m) || !(m.get("id") instanceof String cid) || cid.isBlank()) {
                issues.add(new ValidationIssue(file, p + ".id", "required"));
                continue;
            }
            if (!ids.add(cid)) {
                issues.add(new ValidationIssue(file, p + ".id", "duplicate chapter id '" + cid + "'"));
                continue;
            }
            List<String> quests = strings(m.get("quests"));
            if (quests.isEmpty()) {
                issues.add(new ValidationIssue(file, p + ".quests", "at least one quest required"));
                continue;
            }
            for (String q : quests) {
                if (!knownQuests.contains(q)) issues.add(new ValidationIssue(file, p + ".quests", "unknown quest '" + q + "'"));
            }
            int required = quests.size();
            if (m.get("required") instanceof Number n) {
                required = n.intValue();
                if (required < 1 || required > quests.size()) {
                    issues.add(new ValidationIssue(file, p + ".required", "must be between 1 and " + quests.size()));
                    continue;
                }
            }
            List<RewardSpec> rewards = RewardParser.parse(m.get("rewards"), file, p + ".rewards", rewardTypes, issues);
            chapters.add(new Chapter(cid, m.get("title") instanceof String t ? t : cid, List.copyOf(quests), required,
                    strings(m.get("requires")), Boolean.TRUE.equals(m.get("optional")), Boolean.TRUE.equals(m.get("hidden")),
                    List.copyOf(rewards)));
            maps.add(m);
        }
        DependencyGraph g = new DependencyGraph();
        for (Chapter c : chapters) {
            g.addNode(c.id());
            for (String r : c.requires()) {
                if (!ids.contains(r)) issues.add(new ValidationIssue(file, "chapters." + c.id() + ".requires", "unknown chapter '" + r + "'"));
                else g.addPrerequisite(c.id(), r);
            }
        }
        g.findCycle().ifPresent(cy -> issues.add(new ValidationIssue(file, "chapters", "circular chapter requirements: " + String.join(" -> ", cy))));

        List<String> endings = strings(root.get("endings"));
        for (String e : endings) if (!knownQuests.contains(e)) issues.add(new ValidationIssue(file, "endings", "unknown quest '" + e + "'"));
        List<RewardSpec> rewards = RewardParser.parse(root.get("rewards"), file, "rewards", rewardTypes, issues);
        if (issues.size() > before) return null;
        return new Questline(id, title, root.get("description") instanceof String d ? d : "", List.copyOf(chapters),
                List.copyOf(endings), List.copyOf(rewards));
    }

    private static List<String> strings(Object raw) {
        List<String> out = new ArrayList<>();
        if (raw instanceof List<?> l) for (Object o : l) out.add(String.valueOf(o));
        return out;
    }
}
