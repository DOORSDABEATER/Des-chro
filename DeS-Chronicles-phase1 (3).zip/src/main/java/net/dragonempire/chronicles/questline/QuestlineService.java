package net.dragonempire.chronicles.questline;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Applies questline state to players: gates quests behind locked chapters, and when a chapter or the whole
 * campaign becomes complete, sets a flag (usable by the questline_stage condition), announces it, and pays
 * its rewards exactly once.
 */
public final class QuestlineService {
    private final ContentManager content;
    private final QuestService quests;

    public QuestlineService(ContentManager content, QuestService quests) {
        this.content = content;
        this.quests = quests;
    }

    public QuestlineProgress.Evaluation evaluate(PlayerState s, Questline line) {
        return QuestlineProgress.evaluate(line, s::completed);
    }

    /** True if the quest belongs to chapters and every chapter containing it is still locked. */
    public boolean locked(PlayerState s, String questId) {
        for (Questline line : content.questlines().values()) {
            if (!QuestlineProgress.questUnlocked(line, questId, evaluate(s, line))) return true;
        }
        return false;
    }

    /** Call after any quest completion (and on login, to catch up after content changes). Idempotent. */
    public void onQuestCompleted(Player p) {
        PlayerState s = quests.state(p);
        if (s == null) return;
        for (Questline line : content.questlines().values()) {
            QuestlineProgress.Evaluation e = evaluate(s, line);
            for (Chapter c : line.chapters()) {
                String flag = "stage:" + line.id() + ":" + c.id();
                if (e.chapters().get(c.id()) == QuestlineProgress.Status.COMPLETE && !s.flags.contains(flag)) {
                    quests.addFlag(p, flag);
                    if (!c.hidden()) {
                        p.sendMessage(Messages.get("questline.chapter", "chapter", line.title() + " - " + c.title()));
                    }
                    quests.awardNamed(p, "questline:" + line.id() + ":" + c.id(), c.rewards());
                }
            }
            String done = "stage:" + line.id() + ":complete";
            if (e.complete() && !s.flags.contains(done)) {
                quests.addFlag(p, done);
                if (e.endingQuest() != null) quests.addFlag(p, "stage:" + line.id() + ":ending:" + e.endingQuest());
                p.showTitle(Title.title(Messages.get("questline.complete.title"), Component.text(line.title(), NamedTextColor.WHITE)));
                quests.awardNamed(p, "questline:" + line.id(), line.rewards());
            }
        }
    }

    /** Chat lines summarising each visible questline for the player. */
    public List<Component> describe(Player p) {
        List<Component> out = new ArrayList<>();
        PlayerState s = quests.state(p);
        if (s == null) return out;
        for (Questline line : content.questlines().values()) {
            QuestlineProgress.Evaluation e = evaluate(s, line);
            out.add(Component.text(line.title() + (e.complete() ? " (complete)" : ""), NamedTextColor.GOLD));
            for (Chapter c : line.chapters()) {
                QuestlineProgress.Status st = e.chapters().get(c.id());
                if (c.hidden() && st != QuestlineProgress.Status.COMPLETE) continue;
                NamedTextColor col = st == QuestlineProgress.Status.COMPLETE ? NamedTextColor.GREEN
                        : st == QuestlineProgress.Status.AVAILABLE ? NamedTextColor.YELLOW : NamedTextColor.DARK_GRAY;
                String mark = st == QuestlineProgress.Status.COMPLETE ? "[x] " : st == QuestlineProgress.Status.AVAILABLE ? "[ ] " : "[locked] ";
                out.add(Component.text("  " + mark + c.title() + (c.optional() ? " (optional)" : ""), col));
            }
        }
        return out;
    }
}
