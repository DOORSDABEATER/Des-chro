package net.dragonempire.chronicles.questline;

import net.dragonempire.chronicles.rewards.RewardSpec;

import java.util.List;

/** required = how many of the chapter's quests finish it. requires = chapter ids that must be complete first. */
public record Chapter(String id, String title, List<String> quests, int required, List<String> requires,
                      boolean optional, boolean hidden, List<RewardSpec> rewards) {}
