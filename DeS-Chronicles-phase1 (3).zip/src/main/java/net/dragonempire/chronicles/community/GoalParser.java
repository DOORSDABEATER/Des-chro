package net.dragonempire.chronicles.community;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class GoalParser {
    private GoalParser() {}

    public static Map<String, GoalDefinition> parse(Map<String, Object> root, String file, List<ValidationIssue> issues) {
        Map<String, GoalDefinition> out = new LinkedHashMap<>();
        if (!(root.get("goals") instanceof Map<?, ?> m)) return out;
        for (Map.Entry<?, ?> e : m.entrySet()) {
            String id = String.valueOf(e.getKey());
            String p = "goals." + id;
            if (!(e.getValue() instanceof Map<?, ?> v)) {
                issues.add(new ValidationIssue(file, p, "must be a map"));
                continue;
            }
            int before = issues.size();
            String title = v.get("title") instanceof String s && !s.isBlank() ? s : null;
            if (title == null) issues.add(new ValidationIssue(file, p + ".title", "required"));
            String key = v.get("key") instanceof String s && !s.isBlank() ? s : null;
            if (key == null) issues.add(new ValidationIssue(file, p + ".key", "required"));
            long target = v.get("target") instanceof Number n ? n.longValue() : 0;
            if (target < 1) issues.add(new ValidationIssue(file, p + ".target", "required, >= 1"));
            if (issues.size() > before) continue;
            out.put(id, new GoalDefinition(id, title, key, target, v.get("message") instanceof String s ? s : ""));
        }
        return out;
    }
}
