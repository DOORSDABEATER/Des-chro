package net.dragonempire.chronicles.community;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.storage.Database;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/**
 * Server-wide counters and goals. The main thread owns the running totals and writes absolute values,
 * so concurrent contributions never race. Goals complete once and are announced to everyone.
 */
public final class CommunityManager {
    private final JavaPlugin plugin;
    private final ContentManager content;
    private final Database db;
    private final Map<String, Long> values = new HashMap<>();
    private final Set<String> done = new HashSet<>();
    private boolean loaded;

    public CommunityManager(JavaPlugin plugin, ContentManager content, Database db) {
        this.plugin = plugin;
        this.content = content;
        this.db = db;
    }

    /** Queued behind the database open; contributions made before loading finishes are dropped with a warning. */
    public void start() {
        db.loadServerState().whenComplete((state, err) -> {
            if (!plugin.isEnabled()) return;
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (err != null) {
                    plugin.getLogger().severe("Could not load community state: " + err);
                    return;
                }
                state.forEach((k, v) -> {
                    try {
                        if (k.startsWith("global:")) values.put(k.substring(7), Long.parseLong(v));
                        else if (k.startsWith("goaldone:")) done.add(k.substring(9));
                    } catch (NumberFormatException e) {
                        plugin.getLogger().severe("Corrupt community value for '" + k + "': " + v);
                    }
                });
                loaded = true;
            });
        });
    }

    public long value(String key) { return values.getOrDefault(key, 0L); }
    public boolean globalAtLeast(String key, long min) { return value(key) >= min; }

    public void add(String key, long amount) {
        if (!loaded) {
            plugin.getLogger().warning("Community counter '" + key + "' contribution of " + amount + " ignored: state is still loading.");
            return;
        }
        long v = values.merge(key, amount, Long::sum);
        db.setServerState("global:" + key, Long.toString(v)).exceptionally(err -> {
            plugin.getLogger().severe("Could not persist community counter " + key + ": " + err);
            return null;
        });
        for (GoalDefinition g : content.goals().values()) {
            if (!g.key().equals(key) || v < g.target() || !done.add(g.id())) continue;
            db.setServerState("goaldone:" + g.id(), "1").exceptionally(err -> {
                plugin.getLogger().severe("Could not persist goal completion " + g.id() + ": " + err);
                return null;
            });
            String msg = g.message().isBlank() ? "<gold><bold>Community goal reached:</bold> <white>" + g.title() : g.message();
            plugin.getServer().broadcast(MiniMessage.miniMessage().deserialize(msg));
        }
    }

    public List<Component> describe() {
        List<Component> out = new ArrayList<>();
        for (GoalDefinition g : content.goals().values()) {
            boolean complete = done.contains(g.id());
            long v = Math.min(value(g.key()), g.target());
            out.add(Component.text(g.title() + ": " + (complete ? "COMPLETE" : v + "/" + g.target()), complete ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        }
        return out;
    }
}
