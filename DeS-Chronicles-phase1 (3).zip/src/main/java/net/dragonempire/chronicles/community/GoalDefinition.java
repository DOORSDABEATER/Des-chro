package net.dragonempire.chronicles.community;

/** A server-wide goal: when the global counter `key` reaches `target`, the goal completes once for everyone. */
public record GoalDefinition(String id, String title, String key, long target, String message) {}
