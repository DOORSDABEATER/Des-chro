package net.dragonempire.chronicles.storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;

/**
 * SQLite storage. Every operation runs on one dedicated thread and returns a future,
 * so callers never block the server thread. Callers must hop back to the main thread
 * before touching Bukkit objects.
 */
public final class Database implements AutoCloseable, net.dragonempire.chronicles.rewards.ClaimStore {

    /** Append-only. Index + 1 is the schema version. Never edit an applied migration. */
    private static final List<List<String>> MIGRATIONS = List.of(
            List.of(
                    """
                    CREATE TABLE player_quests (
                      uuid TEXT NOT NULL,
                      quest_id TEXT NOT NULL,
                      state TEXT NOT NULL,
                      progress TEXT NOT NULL DEFAULT '{}',
                      started_at INTEGER NOT NULL,
                      updated_at INTEGER NOT NULL,
                      PRIMARY KEY (uuid, quest_id))
                    """,
                    """
                    CREATE TABLE completions (
                      uuid TEXT NOT NULL,
                      quest_id TEXT NOT NULL,
                      count INTEGER NOT NULL,
                      last_completed_at INTEGER NOT NULL,
                      PRIMARY KEY (uuid, quest_id))
                    """,
                    """
                    CREATE TABLE reward_claims (
                      uuid TEXT NOT NULL,
                      quest_id TEXT NOT NULL,
                      reward_key TEXT NOT NULL,
                      claimed_at INTEGER NOT NULL,
                      PRIMARY KEY (uuid, quest_id, reward_key))
                    """),
            List.of(
                    """
                    CREATE TABLE player_flags (
                      uuid TEXT NOT NULL,
                      flag TEXT NOT NULL,
                      PRIMARY KEY (uuid, flag))
                    """),
            List.of(
                    """
                    CREATE TABLE server_state (
                      key TEXT NOT NULL PRIMARY KEY,
                      value TEXT NOT NULL)
                    """),
            List.of(
                    """
                    CREATE TABLE player_counters (
                      uuid TEXT NOT NULL,
                      key TEXT NOT NULL,
                      value INTEGER NOT NULL,
                      PRIMARY KEY (uuid, key))
                    """));

    private final Path file;
    private final ExecutorService io;
    private Connection conn;

    public Database(Path file) {
        this.file = file;
        this.io = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "DeS-Chronicles-DB");
            t.setDaemon(true);
            return t;
        });
    }

    public CompletableFuture<Void> open() {
        return CompletableFuture.runAsync(() -> {
            try {
                if (file.getParent() != null) Files.createDirectories(file.getParent());
                conn = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
                try (Statement s = conn.createStatement()) {
                    s.execute("PRAGMA journal_mode=WAL");
                    s.execute("PRAGMA foreign_keys=ON");
                }
                migrate();
            } catch (IOException | SQLException e) {
                throw new CompletionException(e);
            }
        }, io);
    }

    private void migrate() throws SQLException {
        try (Statement s = conn.createStatement()) {
            s.execute("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)");
        }
        int current = 0;
        try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT MAX(version) FROM schema_version")) {
            if (rs.next()) current = rs.getInt(1);
        }
        for (int v = current; v < MIGRATIONS.size(); v++) {
            conn.setAutoCommit(false);
            try (Statement s = conn.createStatement()) {
                for (String sql : MIGRATIONS.get(v)) s.execute(sql);
                try (PreparedStatement ps = conn.prepareStatement("INSERT INTO schema_version(version) VALUES (?)")) {
                    ps.setInt(1, v + 1);
                    ps.executeUpdate();
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public CompletableFuture<Integer> schemaVersion() {
        return CompletableFuture.supplyAsync(() -> {
            try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT MAX(version) FROM schema_version")) {
                return rs.next() ? rs.getInt(1) : 0;
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, io);
    }

    /**
     * Atomically claims a reward. True exactly once per (player, quest, rewardKey);
     * the primary key makes concurrent or repeated claims safe.
     */
    @Override
    public CompletableFuture<Boolean> claimReward(UUID player, String questId, String rewardKey) {
        return CompletableFuture.supplyAsync(() -> {
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT OR IGNORE INTO reward_claims(uuid, quest_id, reward_key, claimed_at) VALUES (?,?,?,?)")) {
                ps.setString(1, player.toString());
                ps.setString(2, questId);
                ps.setString(3, rewardKey);
                ps.setLong(4, System.currentTimeMillis());
                return ps.executeUpdate() == 1;
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, io);
    }

    public CompletableFuture<Void> recordCompletion(UUID player, String questId) {
        return CompletableFuture.runAsync(() -> {
            try (PreparedStatement ps = conn.prepareStatement("""
                    INSERT INTO completions(uuid, quest_id, count, last_completed_at) VALUES (?,?,1,?)
                    ON CONFLICT(uuid, quest_id) DO UPDATE SET count = count + 1, last_completed_at = excluded.last_completed_at
                    """)) {
                ps.setString(1, player.toString());
                ps.setString(2, questId);
                ps.setLong(3, System.currentTimeMillis());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, io);
    }

    public CompletableFuture<Integer> completionCount(UUID player, String questId) {
        return CompletableFuture.supplyAsync(() -> {
            try (PreparedStatement ps = conn.prepareStatement("SELECT count FROM completions WHERE uuid=? AND quest_id=?")) {
                ps.setString(1, player.toString());
                ps.setString(2, questId);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? rs.getInt(1) : 0;
                }
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, io);
    }


    @FunctionalInterface
    private interface SqlCall<T> { T call() throws SQLException; }

    private <T> CompletableFuture<T> async(SqlCall<T> c) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return c.call();
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, io);
    }

    /** Loads everything about a player in one round trip. */
    public CompletableFuture<PlayerData> loadPlayer(UUID player) {
        return async(() -> {
            java.util.Map<String, String> active = new java.util.LinkedHashMap<>();
            java.util.Map<String, Integer> done = new java.util.LinkedHashMap<>();
            java.util.Map<String, Long> last = new java.util.LinkedHashMap<>();
            java.util.Set<String> flags = new java.util.LinkedHashSet<>();
            java.util.Map<String, Integer> counters = new java.util.LinkedHashMap<>();
            String u = player.toString();
            try (PreparedStatement ps = conn.prepareStatement("SELECT key, value FROM player_counters WHERE uuid=?")) {
                ps.setString(1, u);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) counters.put(rs.getString(1), rs.getInt(2)); }
            }
            try (PreparedStatement ps = conn.prepareStatement("SELECT quest_id, progress FROM player_quests WHERE uuid=? AND state='ACTIVE'")) {
                ps.setString(1, u);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) active.put(rs.getString(1), rs.getString(2)); }
            }
            try (PreparedStatement ps = conn.prepareStatement("SELECT quest_id, count, last_completed_at FROM completions WHERE uuid=?")) {
                ps.setString(1, u);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) { done.put(rs.getString(1), rs.getInt(2)); last.put(rs.getString(1), rs.getLong(3)); }
                }
            }
            try (PreparedStatement ps = conn.prepareStatement("SELECT flag FROM player_flags WHERE uuid=?")) {
                ps.setString(1, u);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) flags.add(rs.getString(1)); }
            }
            return new PlayerData(active, done, last, flags, counters);
        });
    }

    public CompletableFuture<Void> saveQuest(UUID player, String questId, String progress) {
        return async(() -> {
            long now = System.currentTimeMillis();
            try (PreparedStatement ps = conn.prepareStatement("""
                    INSERT INTO player_quests(uuid, quest_id, state, progress, started_at, updated_at) VALUES (?,?,'ACTIVE',?,?,?)
                    ON CONFLICT(uuid, quest_id) DO UPDATE SET progress = excluded.progress, updated_at = excluded.updated_at
                    """)) {
                ps.setString(1, player.toString());
                ps.setString(2, questId);
                ps.setString(3, progress);
                ps.setLong(4, now);
                ps.setLong(5, now);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Void> deleteQuest(UUID player, String questId) {
        return async(() -> {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM player_quests WHERE uuid=? AND quest_id=?")) {
                ps.setString(1, player.toString());
                ps.setString(2, questId);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Void> addFlag(UUID player, String flag) {
        return async(() -> {
            try (PreparedStatement ps = conn.prepareStatement("INSERT OR IGNORE INTO player_flags(uuid, flag) VALUES (?,?)")) {
                ps.setString(1, player.toString());
                ps.setString(2, flag);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Void> removeFlag(UUID player, String flag) {
        return async(() -> {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM player_flags WHERE uuid=? AND flag=?")) {
                ps.setString(1, player.toString());
                ps.setString(2, flag);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<java.util.Map<String, String>> loadServerState() {
        return async(() -> {
            java.util.Map<String, String> out = new java.util.LinkedHashMap<>();
            try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT key, value FROM server_state")) {
                while (rs.next()) out.put(rs.getString(1), rs.getString(2));
            }
            return out;
        });
    }

    public CompletableFuture<Void> setServerState(String key, String value) {
        return async(() -> {
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO server_state(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")) {
                ps.setString(1, key);
                ps.setString(2, value);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Void> deleteServerState(String key) {
        return async(() -> {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM server_state WHERE key=?")) {
                ps.setString(1, key);
                ps.executeUpdate();
            }
            return null;
        });
    }

    /** Stores the absolute value; the main thread owns the running total so there is no read-modify-write race. */
    public CompletableFuture<Void> setCounter(UUID player, String key, int value) {
        return async(() -> {
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO player_counters(uuid, key, value) VALUES (?,?,?) ON CONFLICT(uuid, key) DO UPDATE SET value = excluded.value")) {
                ps.setString(1, player.toString());
                ps.setString(2, key);
                ps.setInt(3, value);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public record TopEntry(UUID player, int count) {}

    /** Most completions of a quest, highest first. */
    public CompletableFuture<List<TopEntry>> topCompletions(String questId, int limit) {
        return async(() -> {
            List<TopEntry> out = new java.util.ArrayList<>();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT uuid, count FROM completions WHERE quest_id=? ORDER BY count DESC, last_completed_at ASC LIMIT ?")) {
                ps.setString(1, questId);
                ps.setInt(2, limit);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(new TopEntry(UUID.fromString(rs.getString(1)), rs.getInt(2))); }
            }
            return out;
        });
    }

    /** Removes active state, completion count and reward claims (including repeat claims) in one transaction. */
    public CompletableFuture<Void> resetQuest(UUID player, String questId) {
        return async(() -> {
            conn.setAutoCommit(false);
            try {
                for (String sql : new String[]{
                        "DELETE FROM player_quests WHERE uuid=? AND quest_id=?",
                        "DELETE FROM completions WHERE uuid=? AND quest_id=?",
                        "DELETE FROM reward_claims WHERE uuid=? AND (quest_id=? OR quest_id LIKE ?)"}) {
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setString(1, player.toString());
                        ps.setString(2, questId);
                        if (sql.contains("LIKE")) ps.setString(3, questId + "#%");
                        ps.executeUpdate();
                    }
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
            return null;
        });
    }

    @Override
    public void close() {
        io.execute(() -> {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("[DeS-Chronicles] failed to close database: " + e);
            }
        });
        io.shutdown();
        try {
            if (!io.awaitTermination(10, TimeUnit.SECONDS)) io.shutdownNow();
        } catch (InterruptedException e) {
            io.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
