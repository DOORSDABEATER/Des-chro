package net.dragonempire.chronicles.actions;

import net.dragonempire.chronicles.dialogue.DialogueAction;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Runs the fixed set of validated dialogue actions. There is no scripting: unknown types never load. */
public final class ActionExecutor {
    public static final Set<String> KNOWN = Set.of("start_quest", "complete_quest", "set_flag", "clear_flag", "message", "sound", "title",
            "play_cutscene", "spawn_boss", "add_counter", "start_escort", "open_shop", "start_template");

    private final QuestService quests;
    private net.dragonempire.chronicles.cutscenes.CutsceneManager cutscenes;
    private net.dragonempire.chronicles.bosses.BossManager bosses;
    private net.dragonempire.chronicles.escorts.EscortManager escorts;
    private net.dragonempire.chronicles.npc.ShopMenu shops;

    public ActionExecutor(QuestService quests) {
        this.quests = quests;
    }

    public void setCutscenes(net.dragonempire.chronicles.cutscenes.CutsceneManager c) { this.cutscenes = c; }
    public void setEscorts(net.dragonempire.chronicles.escorts.EscortManager e) { this.escorts = e; }
    public void setShops(net.dragonempire.chronicles.npc.ShopMenu s) { this.shops = s; }
    public void setBosses(net.dragonempire.chronicles.bosses.BossManager b) { this.bosses = b; }

    public void run(Player p, List<DialogueAction> actions) {
        for (DialogueAction a : actions) run(p, a);
    }

    private void run(Player p, DialogueAction a) {
        Map<String, Object> m = a.params();
        switch (a.type()) {
            case "start_quest" -> {
                String err = quests.start(p, str(m, "quest"), false);
                if (err != null) p.sendMessage(Component.text(err, NamedTextColor.GRAY));
            }
            case "complete_quest" -> quests.complete(p, str(m, "quest"));
            case "add_counter" -> quests.addCounter(p, str(m, "key"), m.get("amount") instanceof Number n ? n.intValue() : 0);
            case "set_flag" -> quests.addFlag(p, str(m, "flag"));
            case "clear_flag" -> quests.removeFlag(p, str(m, "flag"));
            case "message" -> p.sendMessage(MiniMessage.miniMessage().deserialize(str(m, "text").replace("{player}", p.getName())));
            case "title" -> p.showTitle(Title.title(
                    MiniMessage.miniMessage().deserialize(str(m, "title")),
                    MiniMessage.miniMessage().deserialize(m.get("subtitle") == null ? "" : str(m, "subtitle"))));
            case "play_cutscene" -> {
                String err = cutscenes == null ? "cutscenes unavailable" : cutscenes.play(str(m, "cutscene"), p);
                if (err != null) p.sendMessage(Component.text(err, NamedTextColor.GRAY));
            }
            case "start_escort" -> {
                String err = escorts == null ? "escorts unavailable" : escorts.start(p, str(m, "escort"));
                if (err != null) p.sendMessage(Component.text(err, NamedTextColor.GRAY));
            }
            case "start_template" -> {
                String err = quests.startTemplate(p, str(m, "template"));
                if (err != null) p.sendMessage(Component.text(err, NamedTextColor.GRAY));
            }
            case "open_shop" -> { if (shops != null) shops.open(p, str(m, "npc")); }
            case "spawn_boss" -> {
                String err = bosses == null ? "bosses unavailable" : bosses.spawn(str(m, "boss"), p);
                if (err != null) p.sendMessage(Component.text(err, NamedTextColor.GRAY));
            }
            case "sound" -> {
                try {
                    float vol = m.get("volume") instanceof Number n ? n.floatValue() : 1f;
                    float pitch = m.get("pitch") instanceof Number n ? n.floatValue() : 1f;
                    p.playSound(Sound.sound(Key.key(str(m, "sound")), Sound.Source.MASTER, vol, pitch));
                } catch (RuntimeException e) {
                    p.sendMessage(Component.text("(invalid sound in dialogue: " + e.getMessage() + ")", NamedTextColor.RED));
                }
            }
            default -> { }
        }
    }

    private static String str(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v == null ? "" : String.valueOf(v);
    }
}
