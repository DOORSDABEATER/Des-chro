package net.dragonempire.chronicles.resourcepack;

/**
 * Maps logical sound names to a resource key. By default vanilla sounds are used, so the plugin works with no pack.
 * With resourcepack.custom_sounds enabled (players must load the DeS-Chronicles pack) the matching
 * deschronicles:* sound events from the pack are used instead.
 */
public final class Sounds {
    private static volatile boolean custom;

    private Sounds() {}

    public static void configure(boolean useCustom) { custom = useCustom; }

    public static String resolve(String logical) {
        if (custom) return "deschronicles:" + logical;
        return switch (logical) {
            case "quest.start" -> "minecraft:entity.experience_orb.pickup";
            case "quest.stage" -> "minecraft:entity.player.levelup";
            case "quest.complete" -> "minecraft:ui.toast.challenge_complete";
            case "discovery" -> "minecraft:block.amethyst_block.chime";
            case "dialogue.blip" -> "minecraft:block.note_block.hat";
            default -> "minecraft:ui.button.click";
        };
    }
}
