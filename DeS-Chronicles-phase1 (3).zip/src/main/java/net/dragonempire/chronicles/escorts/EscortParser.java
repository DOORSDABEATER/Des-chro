package net.dragonempire.chronicles.escorts;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class EscortParser {
    private EscortParser() {}

    public static Map<String, EscortDefinition> parse(Map<String, Object> root, String file, List<ValidationIssue> issues) {
        Map<String, EscortDefinition> out = new LinkedHashMap<>();
        if (!(root.get("escorts") instanceof Map<?, ?> m)) return out;
        for (Map.Entry<?, ?> e : m.entrySet()) {
            String id = String.valueOf(e.getKey());
            String p = "escorts." + id;
            if (!(e.getValue() instanceof Map<?, ?> v)) {
                issues.add(new ValidationIssue(file, p, "must be a map"));
                continue;
            }
            int before = issues.size();
            Object start = v.get("start"), dest = v.get("destination");
            if (!(start instanceof Map<?, ?> s) || !(s.get("world") instanceof String world) || !(s.get("x") instanceof Number sx)
                    || !(s.get("y") instanceof Number sy) || !(s.get("z") instanceof Number sz)) {
                issues.add(new ValidationIssue(file, p + ".start", "needs world, x, y, z"));
                continue;
            }
            if (!(dest instanceof Map<?, ?> d) || !(d.get("x") instanceof Number dx) || !(d.get("y") instanceof Number dy) || !(d.get("z") instanceof Number dz)) {
                issues.add(new ValidationIssue(file, p + ".destination", "needs x, y, z (same world as start)"));
                continue;
            }
            double radius = v.get("radius") instanceof Number n ? n.doubleValue() : 4;
            if (radius <= 0) issues.add(new ValidationIssue(file, p + ".radius", "must be > 0"));
            double health = v.get("health") instanceof Number n ? n.doubleValue() : 20;
            if (health <= 0 || health > 1024) issues.add(new ValidationIssue(file, p + ".health", "must be in (0, 1024]"));
            double speed = v.get("speed") instanceof Number n ? n.doubleValue() : 1.2;
            if (speed <= 0 || speed > 3) issues.add(new ValidationIssue(file, p + ".speed", "must be in (0, 3]"));
            int limit = v.get("time_limit_seconds") instanceof Number n ? n.intValue() : 0;
            if (limit < 0) issues.add(new ValidationIssue(file, p + ".time_limit_seconds", "must be >= 0 (0 = none)"));
            if (issues.size() > before) continue;
            out.put(id, new EscortDefinition(id, v.get("name") instanceof String n ? n : id,
                    v.get("entity") instanceof String n ? n.toUpperCase(Locale.ROOT) : "VILLAGER",
                    !Boolean.FALSE.equals(v.get("configured")), world, sx.doubleValue(), sy.doubleValue(), sz.doubleValue(),
                    dx.doubleValue(), dy.doubleValue(), dz.doubleValue(), radius, health, limit, speed));
        }
        return out;
    }
}
