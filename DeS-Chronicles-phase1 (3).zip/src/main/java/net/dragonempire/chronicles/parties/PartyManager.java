package net.dragonempire.chronicles.parties;

import java.util.*;

/** In-memory parties. Every method returns null on success or a player-facing error. Main thread only. */
public final class PartyManager {
    private static final long INVITE_MS = 60_000;

    private record Invite(UUID party, long expires) {}

    private final int maxSize;
    private final Map<UUID, Set<UUID>> parties = new HashMap<>();   // leader -> members (including leader)
    private final Map<UUID, UUID> leaderOf = new HashMap<>();       // member -> leader
    private final Map<UUID, Invite> invites = new HashMap<>();      // invitee -> invite
    private Runnable onChange = () -> { };

    /** Called after every successful create/accept/leave so the plugin can persist parties. */
    public void setOnChange(Runnable r) { this.onChange = r; }

    /** Leader to members (leader first), for persistence. */
    public Map<UUID, List<UUID>> snapshot() {
        Map<UUID, List<UUID>> out = new LinkedHashMap<>();
        for (Map.Entry<UUID, Set<UUID>> e : parties.entrySet()) {
            List<UUID> members = new ArrayList<>(e.getValue());
            members.remove(e.getKey());
            members.add(0, e.getKey());
            out.put(e.getKey(), members);
        }
        return out;
    }

    /** Replaces all parties (used once at startup). Entries that are invalid or conflict are skipped. */
    public void restore(Map<UUID, List<UUID>> saved) {
        parties.clear();
        leaderOf.clear();
        for (Map.Entry<UUID, List<UUID>> e : saved.entrySet()) {
            UUID leader = e.getKey();
            if (leaderOf.containsKey(leader)) continue;
            Set<UUID> members = new LinkedHashSet<>();
            members.add(leader);
            for (UUID m : e.getValue()) if (members.size() < maxSize && !leaderOf.containsKey(m) && !m.equals(leader)) members.add(m);
            if (members.size() < 2) continue; // a one-person party is not worth restoring
            parties.put(leader, members);
            for (UUID m : members) leaderOf.put(m, leader);
        }
    }

    public PartyManager(int maxSize) {
        this.maxSize = maxSize;
    }

    public String create(UUID player) {
        if (leaderOf.containsKey(player)) return "You are already in a party.";
        Set<UUID> s = new LinkedHashSet<>();
        s.add(player);
        parties.put(player, s);
        leaderOf.put(player, player);
        onChange.run();
        return null;
    }

    public String invite(UUID inviter, UUID target, long now) {
        UUID leader = leaderOf.get(inviter);
        if (leader == null) return "You are not in a party. Create one first.";
        if (!leader.equals(inviter)) return "Only the party leader can invite.";
        if (inviter.equals(target)) return "You cannot invite yourself.";
        if (leaderOf.containsKey(target)) return "That player is already in a party.";
        if (parties.get(leader).size() >= maxSize) return "Your party is full.";
        invites.put(target, new Invite(leader, now + INVITE_MS));
        return null;
    }

    public String accept(UUID invitee, long now) {
        Invite inv = invites.remove(invitee);
        if (inv == null || inv.expires() < now) return "You have no pending party invite.";
        Set<UUID> members = parties.get(inv.party());
        if (members == null) return "That party no longer exists.";
        if (leaderOf.containsKey(invitee)) return "You are already in a party.";
        if (members.size() >= maxSize) return "That party is full.";
        members.add(invitee);
        leaderOf.put(invitee, inv.party());
        onChange.run();
        return null;
    }

    public String leave(UUID player) {
        UUID leader = leaderOf.remove(player);
        if (leader == null) return "You are not in a party.";
        Set<UUID> members = parties.get(leader);
        members.remove(player);
        if (members.isEmpty()) {
            parties.remove(leader);
        } else if (leader.equals(player)) {
            UUID next = members.iterator().next();   // promote the longest-standing member
            parties.remove(leader);
            parties.put(next, members);
            for (UUID m : members) leaderOf.put(m, next);
        }
        onChange.run();
        return null;
    }

    /** Members including the player; just the player if they have no party. */
    public Set<UUID> membersOf(UUID player) {
        UUID leader = leaderOf.get(player);
        if (leader == null) return Set.of(player);
        return Collections.unmodifiableSet(parties.get(leader));
    }

    public boolean inParty(UUID player) { return leaderOf.containsKey(player); }
}
