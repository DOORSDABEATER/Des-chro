package net.dragonempire.chronicles.parties;

import net.dragonempire.chronicles.storage.Database;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/** Persists parties in the database's server_state table so they survive restarts. */
public final class PartyStore {
    private static final String PREFIX = "party:";

    private final JavaPlugin plugin;
    private final Database db;
    private final PartyManager parties;
    private Set<String> written = new HashSet<>();

    public PartyStore(JavaPlugin plugin, Database db, PartyManager parties) {
        this.plugin = plugin;
        this.db = db;
        this.parties = parties;
    }

    /** Restores saved parties, then starts saving every change. Queued behind the database open. */
    public void load() {
        db.loadServerState().whenComplete((state, err) -> {
            if (!plugin.isEnabled()) return;
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (err != null) {
                    plugin.getLogger().severe("Could not load saved parties: " + err);
                } else {
                    Map<UUID, List<UUID>> saved = new LinkedHashMap<>();
                    for (Map.Entry<String, String> e : state.entrySet()) {
                        if (!e.getKey().startsWith(PREFIX)) continue;
                        written.add(e.getKey());
                        try {
                            UUID leader = UUID.fromString(e.getKey().substring(PREFIX.length()));
                            List<UUID> members = new ArrayList<>();
                            for (String m : e.getValue().split(",")) if (!m.isBlank()) members.add(UUID.fromString(m.trim()));
                            saved.put(leader, members);
                        } catch (IllegalArgumentException ex) {
                            plugin.getLogger().warning("Ignoring corrupt saved party '" + e.getKey() + "': " + ex.getMessage());
                        }
                    }
                    parties.restore(saved);
                }
                parties.setOnChange(this::save);
            });
        });
    }

    private void save() {
        Set<String> now = new HashSet<>();
        for (Map.Entry<UUID, List<UUID>> e : parties.snapshot().entrySet()) {
            String key = PREFIX + e.getKey();
            now.add(key);
            StringBuilder sb = new StringBuilder();
            for (UUID m : e.getValue()) sb.append(sb.length() == 0 ? "" : ",").append(m);
            db.setServerState(key, sb.toString()).exceptionally(err -> {
                plugin.getLogger().severe("Could not save party " + key + ": " + err);
                return null;
            });
        }
        for (String stale : written) {
            if (!now.contains(stale)) {
                db.deleteServerState(stale).exceptionally(err -> {
                    plugin.getLogger().severe("Could not remove party " + stale + ": " + err);
                    return null;
                });
            }
        }
        written = now;
    }
}
