package net.dragonempire.chronicles.quest;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.List;
import java.util.Map;

/** files maps quest id to the file name it was loaded from. */
public record QuestLoadResult(Map<String, QuestDefinition> quests, List<ValidationIssue> issues, Map<String, String> files) {
}
