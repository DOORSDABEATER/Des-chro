package net.dragonempire.chronicles.quest;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.Set;

/** Daily/weekly reset windows. Daily resets at local midnight; weekly at local Monday midnight. */
public final class ResetPolicy {
    public static final Set<String> VALID = Set.of("none", "daily", "weekly");

    private ResetPolicy() {}

    public static boolean active(String reset) { return reset.equals("daily") || reset.equals("weekly"); }

    public static Instant periodStart(String reset, Instant now, ZoneId zone) {
        ZonedDateTime z = now.atZone(zone);
        return switch (reset) {
            case "daily" -> z.toLocalDate().atStartOfDay(zone).toInstant();
            case "weekly" -> z.toLocalDate().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).atStartOfDay(zone).toInstant();
            default -> throw new IllegalArgumentException("not a resetting quest: " + reset);
        };
    }

    public static Instant nextReset(String reset, Instant now, ZoneId zone) {
        ZonedDateTime start = periodStart(reset, now, zone).atZone(zone);
        return (reset.equals("daily") ? start.plusDays(1) : start.plusWeeks(1)).toInstant();
    }

    /** True if the quest was last completed before the current period began. */
    public static boolean availableAgain(String reset, long lastCompletedMillis, Instant now, ZoneId zone) {
        return Instant.ofEpochMilli(lastCompletedMillis).isBefore(periodStart(reset, now, zone));
    }
}
