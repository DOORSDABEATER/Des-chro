package net.dragonempire.chronicles.quest;

import net.dragonempire.chronicles.dialogue.DialogueAction;
import net.dragonempire.chronicles.objectives.QuestPlan;
import net.dragonempire.chronicles.rewards.RewardSpec;

import java.util.List;

/**
 * reset: none | daily | weekly (resetting quests can be redone once per period).
 * event: id of an event that must be active to start the quest, or blank.
 * requiredLevel / maxLevel: player XP level window to start the quest (maxLevel 0 = no upper limit, exclusive).
 * partyShared: objective progress is shared with party members within partyDistance blocks.
 */
public record QuestDefinition(
        String id,
        String title,
        String description,
        QuestStatus status,
        String giver,
        String category,
        boolean repeatable,
        boolean hidden,
        String reset,
        String event,
        boolean partyShared,
        double partyDistance,
        int requiredLevel,
        int maxLevel,
        List<String> prerequisites,
        List<String> excludes,
        QuestPlan plan,
        List<RewardSpec> rewards,
        List<DialogueAction> onStart,
        List<DialogueAction> onComplete) {
}
