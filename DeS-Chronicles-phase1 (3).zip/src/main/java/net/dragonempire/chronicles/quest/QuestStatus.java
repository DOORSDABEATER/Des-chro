package net.dragonempire.chronicles.quest;

public enum QuestStatus { DRAFT, PUBLISHED, DISABLED }
