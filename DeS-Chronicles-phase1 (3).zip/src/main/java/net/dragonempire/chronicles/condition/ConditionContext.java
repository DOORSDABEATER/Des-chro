package net.dragonempire.chronicles.condition;

/** Everything a condition can ask about a player. Implemented by the plugin from live state. */
public interface ConditionContext {
    boolean hasCompletedQuest(String questId);
    boolean hasActiveQuest(String questId);
    boolean hasItem(String material, int amount);
    boolean hasPermission(String node);
    int level();
    boolean hasAchievement(String id);
    boolean hasVisited(String location);
    boolean hasDefeatedBoss(String bossId);
    boolean choseOption(String dialogueId, String choiceId);
    boolean atQuestlineStage(String questline, String stage);
    boolean eventActive(String eventId);
    boolean globalAtLeast(String key, long min);
    int counter(String key);
}
