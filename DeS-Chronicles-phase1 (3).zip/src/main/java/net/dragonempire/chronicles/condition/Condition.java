package net.dragonempire.chronicles.condition;

@FunctionalInterface
public interface Condition {
    boolean test(ConditionContext ctx);
}
