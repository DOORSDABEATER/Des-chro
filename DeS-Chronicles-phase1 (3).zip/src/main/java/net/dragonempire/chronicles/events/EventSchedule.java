package net.dragonempire.chronicles.events;

import java.time.Instant;

public final class EventSchedule {
    private EventSchedule() {}

    /**
     * override is "on", "off" or null (follow the schedule). A manual "on" still ends at the event's end time.
     * Events without a start/end window only run when switched on manually.
     */
    public static boolean isActive(EventDefinition d, String override, Instant now) {
        if ("off".equals(override)) return false;
        boolean beforeEnd = d.end() == null || now.isBefore(d.end());
        if ("on".equals(override)) return beforeEnd;
        if (d.start() == null && d.end() == null) return false;
        return (d.start() == null || !now.isBefore(d.start())) && beforeEnd;
    }
}
