package net.dragonempire.chronicles.studio;

import java.util.*;

/**
 * Pure structure edits used by the command editors, kept free of Bukkit so they can be unit tested.
 * Quest stages are lists of {mode, objectives:[...]}; a flat `objectives:` list means one sequential stage.
 */
public final class DocOps {
    private DocOps() {}

    /** Mutable copies of the quest's stages, converting a flat objectives list into a single stage if needed. */
    public static List<Map<String, Object>> stagesOf(List<? extends Map<?, ?>> stages, List<? extends Map<?, ?>> flatObjectives) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (stages != null && !stages.isEmpty()) {
            for (Map<?, ?> st : stages) out.add(copyStage(st));
        } else if (flatObjectives != null && !flatObjectives.isEmpty()) {
            Map<String, Object> stage = new LinkedHashMap<>();
            stage.put("mode", "sequential");
            stage.put("objectives", copyAll(flatObjectives));
            out.add(stage);
        }
        return out;
    }

    private static Map<String, Object> copyStage(Map<?, ?> st) {
        Map<String, Object> copy = new LinkedHashMap<>();
        for (Map.Entry<?, ?> e : st.entrySet()) copy.put(String.valueOf(e.getKey()), e.getValue());
        Object objs = copy.get("objectives");
        copy.put("objectives", objs instanceof List<?> l ? copyAll(l) : new ArrayList<Map<String, Object>>());
        return copy;
    }

    private static List<Map<String, Object>> copyAll(List<?> maps) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object o : maps) {
            if (!(o instanceof Map<?, ?> m)) continue;
            Map<String, Object> c = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : m.entrySet()) c.put(String.valueOf(e.getKey()), e.getValue());
            out.add(c);
        }
        return out;
    }

    /** Next unused objective id across all stages: o1, o2, ... */
    public static String nextObjectiveId(List<Map<String, Object>> stages) {
        Set<String> used = new HashSet<>();
        int count = 0;
        for (Map<String, Object> st : stages) {
            if (st.get("objectives") instanceof List<?> l) {
                for (Object o : l) {
                    count++;
                    if (o instanceof Map<?, ?> m) used.add(String.valueOf(m.get("id")));
                }
            }
        }
        int n = count + 1;
        while (used.contains("o" + n)) n++;
        return "o" + n;
    }

    /** stageNumber is 1-based; 0 means the last stage. Returns an error message or null. */
    @SuppressWarnings("unchecked")
    public static String addObjective(List<Map<String, Object>> stages, int stageNumber, Map<String, Object> objective) {
        if (stages.isEmpty()) return "this quest has no stages or objectives yet";
        int index = stageNumber == 0 ? stages.size() - 1 : stageNumber - 1;
        if (index < 0 || index >= stages.size()) return "stage " + stageNumber + " does not exist (the quest has " + stages.size() + ")";
        ((List<Map<String, Object>>) stages.get(index).get("objectives")).add(objective);
        return null;
    }

    public static Map<String, Object> newStage(String mode, Map<String, Object> firstObjective) {
        Map<String, Object> stage = new LinkedHashMap<>();
        stage.put("mode", mode);
        List<Map<String, Object>> objs = new ArrayList<>();
        objs.add(firstObjective);
        stage.put("objectives", objs);
        return stage;
    }

    /**
     * Appends an entry to a dialogue choice's `if` or `actions` list. An existing single-map `if` is promoted to a list
     * (which means AND). Returns an error message or null.
     */
    public static String addToChoice(List<Map<String, Object>> choices, String choiceId, String listKey, Map<String, Object> entry, Map<String, Object> out) {
        for (Map<String, Object> c : choices) {
            if (!choiceId.equals(String.valueOf(c.get("id")))) continue;
            List<Object> list = new ArrayList<>();
            Object cur = c.get(listKey);
            if (cur instanceof List<?> l) list.addAll(l);
            else if (cur != null) list.add(cur);
            list.add(entry);
            c.put(listKey, list);
            out.putAll(c);
            return null;
        }
        return "no choice called '" + choiceId + "' in that node";
    }

    /** Copies a node's choice maps so they can be edited. */
    public static List<Map<String, Object>> choicesOf(List<? extends Map<?, ?>> raw) {
        return copyAll(raw);
    }

    public static Object scalar(String v) {
        if (v.equalsIgnoreCase("true") || v.equalsIgnoreCase("false")) return Boolean.parseBoolean(v);
        try {
            if (v.matches("-?\\d{1,9}")) return Integer.parseInt(v);
            if (v.matches("-?\\d+\\.\\d+")) return Double.parseDouble(v);
        } catch (NumberFormatException ignored) {
            // falls through to a plain string
        }
        return v;
    }

    /** Parses key=value tokens into an ordered map starting with the given type. Returns null on a malformed token. */
    public static Map<String, Object> typed(String type, List<String> tokens) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", type);
        for (String t : tokens) {
            int eq = t.indexOf('=');
            if (eq < 1) return null;
            m.put(t.substring(0, eq), scalar(t.substring(eq + 1)));
        }
        return m;
    }
}
