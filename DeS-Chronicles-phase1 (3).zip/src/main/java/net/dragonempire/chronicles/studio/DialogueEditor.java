package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/** Command-driven dialogue authoring: every change is validated by a reload and rolled back if it breaks the file. */
public final class DialogueEditor {
    private static final Pattern ID = Pattern.compile("[a-z0-9_]{3,48}");
    private static final Pattern NODE = Pattern.compile("[a-z0-9_]{1,32}");

    private final ChroniclesPlugin plugin;

    public DialogueEditor(ChroniclesPlugin plugin) {
        this.plugin = plugin;
    }

    private Path file(String id) { return plugin.getDataFolder().toPath().resolve("dialogues").resolve(id + ".yml"); }

    public String create(String id) {
        if (!ID.matcher(id).matches()) return "Dialogue ids must match [a-z0-9_]{3,48}.";
        if (Files.exists(file(id)) || plugin.content().dialogues().containsKey(id)) return "A dialogue with that id already exists.";
        YamlConfiguration y = new YamlConfiguration();
        y.set("speaker", "Someone");
        y.set("color", "#ffffff");
        y.set("start", "start");
        y.set("nodes.start.pages", List.of("Hello, {player}."));
        y.set("nodes.start.choices", List.of(new LinkedHashMap<>(Map.of("id", "bye", "text", "Goodbye.", "next", "end"))));
        return YamlDocs.create(plugin, file(id), y, () -> plugin.content().dialogues().containsKey(id));
    }

    public String setSpeaker(String id, String speaker, String color) {
        return YamlDocs.mutate(plugin, file(id), y -> {
            y.set("speaker", speaker);
            if (color != null) y.set("color", color);
        }, () -> plugin.content().dialogues().containsKey(id));
    }

    public String addNode(String id, String node, String text) {
        if (!NODE.matcher(node).matches()) return "Node ids must match [a-z0-9_]{1,32}.";
        return YamlDocs.mutate(plugin, file(id), y -> {
            if (y.contains("nodes." + node)) throw new IllegalArgumentException("node '" + node + "' already exists");
            y.set("nodes." + node + ".pages", List.of(text));
        }, () -> plugin.content().dialogues().containsKey(id));
    }

    /**
     * Adds a condition (listKey "if") or an action (listKey "actions") to an existing choice. Params are key=value tokens,
     * for example: addcondition npc node choice completed_quest quest=fa_01. Unknown types are rejected by validation.
     */
    public String addToChoice(String id, String node, String choiceId, String listKey, String type, List<String> params) {
        Map<String, Object> entry = DocOps.typed(type.toLowerCase(Locale.ROOT), params);
        if (entry == null) return "Parameters look like key=value.";
        return YamlDocs.mutate(plugin, file(id), y -> {
            String path = "nodes." + node + ".choices";
            if (!y.contains("nodes." + node)) throw new IllegalArgumentException("no node called '" + node + "'");
            List<Map<String, Object>> choices = DocOps.choicesOf(y.getMapList(path));
            String err = DocOps.addToChoice(choices, choiceId, listKey, entry, new LinkedHashMap<>());
            if (err != null) throw new IllegalArgumentException(err);
            y.set(path, choices);
        }, () -> plugin.content().dialogues().containsKey(id));
    }

    /** next is a node id or "end". The target node must already exist (add it first), or the change is rejected. */
    public String addChoice(String id, String node, String choiceId, String next, String text) {
        if (!NODE.matcher(choiceId).matches()) return "Choice ids must match [a-z0-9_]{1,32}.";
        return YamlDocs.mutate(plugin, file(id), y -> {
            if (!y.contains("nodes." + node)) throw new IllegalArgumentException("no node called '" + node + "'");
            List<Map<?, ?>> choices = new ArrayList<>(y.getMapList("nodes." + node + ".choices"));
            Map<String, Object> c = new LinkedHashMap<>();
            c.put("id", choiceId);
            c.put("text", text);
            c.put("next", next);
            choices.add(c);
            y.set("nodes." + node + ".choices", choices);
        }, () -> plugin.content().dialogues().containsKey(id));
    }
}
