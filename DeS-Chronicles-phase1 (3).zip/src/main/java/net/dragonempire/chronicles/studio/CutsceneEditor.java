package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/** Command-driven cutscene authoring with the same validate-and-rollback behaviour as the other editors. */
public final class CutsceneEditor {
    private static final Pattern ID = Pattern.compile("[a-z0-9_]{3,48}");

    private final ChroniclesPlugin plugin;

    public CutsceneEditor(ChroniclesPlugin plugin) {
        this.plugin = plugin;
    }

    private Path file(String id) { return plugin.getDataFolder().toPath().resolve("cutscenes").resolve(id + ".yml"); }

    public String create(String id) {
        if (!ID.matcher(id).matches()) return "Cutscene ids must match [a-z0-9_]{3,48}.";
        if (Files.exists(file(id)) || plugin.content().cutscenes().containsKey(id)) return "A cutscene with that id already exists.";
        YamlConfiguration y = new YamlConfiguration();
        y.set("skippable", true);
        y.set("steps", List.of(new LinkedHashMap<>(Map.of("at", 0, "type", "message", "text", "The scene begins."))));
        return YamlDocs.create(plugin, file(id), y, () -> plugin.content().cutscenes().containsKey(id));
    }

    /** params are key=value tokens, for example: addstep intro 40 title title=Hello subtitle=World */
    public String addStep(String id, int at, String type, List<String> params) {
        Map<String, Object> step = new LinkedHashMap<>();
        step.put("at", at);
        step.put("type", type.toLowerCase(Locale.ROOT));
        for (String p : params) {
            int eq = p.indexOf('=');
            if (eq < 1) return "Parameters look like key=value (got '" + p + "').";
            step.put(p.substring(0, eq), scalar(p.substring(eq + 1)));
        }
        return YamlDocs.mutate(plugin, file(id), y -> {
            List<Map<?, ?>> steps = new ArrayList<>(y.getMapList("steps"));
            steps.add(step);
            y.set("steps", steps);
        }, () -> plugin.content().cutscenes().containsKey(id));
    }

    private static Object scalar(String v) {
        if (v.equalsIgnoreCase("true") || v.equalsIgnoreCase("false")) return Boolean.parseBoolean(v);
        try {
            if (v.matches("-?\\d{1,9}")) return Integer.parseInt(v);
            if (v.matches("-?\\d+\\.\\d+")) return Double.parseDouble(v);
        } catch (NumberFormatException ignored) {
            // falls through to a plain string
        }
        return v;
    }
}
