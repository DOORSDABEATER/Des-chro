package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Shared edit-validate-rollback routine for command-driven content editors. Methods return null on success. */
final class YamlDocs {
    private YamlDocs() {}

    /** Creates a new file; deletes it again if the content does not load afterwards. */
    static String create(ChroniclesPlugin plugin, Path file, YamlConfiguration doc, BooleanSupplier loaded) {
        try {
            Files.createDirectories(file.getParent());
            doc.save(file.toFile());
        } catch (IOException e) {
            return "Could not write " + file.getFileName() + ": " + e.getMessage();
        }
        List<ValidationIssue> issues = plugin.reloadContent();
        if (loaded.getAsBoolean()) return null;
        try {
            Files.deleteIfExists(file);
        } catch (IOException ignored) {
            // the next reload reports the leftover file; nothing more to do here
        }
        plugin.reloadContent();
        return "Could not create it: " + firstIssues(issues, file.getFileName().toString());
    }

    /** Applies a change to an existing file; a change that stops it loading is rolled back. */
    static String mutate(ChroniclesPlugin plugin, Path file, Consumer<YamlConfiguration> change, BooleanSupplier loaded) {
        if (!Files.isRegularFile(file)) return "No such file: " + file.getFileName() + " (only files named after the id can be edited here).";
        String original;
        try {
            original = Files.readString(file, StandardCharsets.UTF_8);
            YamlConfiguration y = new YamlConfiguration();
            y.options().parseComments(true);
            y.load(file.toFile());
            change.accept(y);
            y.save(file.toFile());
        } catch (IllegalArgumentException e) {
            return "Rejected: " + e.getMessage();
        } catch (IOException | InvalidConfigurationException e) {
            return "Could not edit " + file.getFileName() + ": " + e.getMessage();
        }
        List<ValidationIssue> issues = plugin.reloadContent();
        if (loaded.getAsBoolean()) return null;
        try {
            Files.writeString(file, original, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "That change made the file invalid AND it could not be restored (" + e.getMessage() + "). Fix " + file.getFileName() + " by hand.";
        }
        plugin.reloadContent();
        return "Rejected, the file would be invalid: " + firstIssues(issues, file.getFileName().toString());
    }

    static String firstIssues(List<ValidationIssue> issues, String file) {
        StringBuilder sb = new StringBuilder();
        issues.stream().filter(i -> i.file().equals(file)).limit(3).forEach(i -> sb.append("\n - ").append(i));
        return sb.length() == 0 ? "see /desquests validate" : sb.toString();
    }
}
