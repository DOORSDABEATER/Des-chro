package net.dragonempire.chronicles.hud;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.objectives.QuestProgress;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.*;

/** Opt-in sidebar listing tracked quests. Rebuilt only when quest state changes. Players choose with /quests sidebar. */
public final class SidebarService {
    private static final String SECTION = "\u00a7";
    private static final int MAX_LINES = 12;

    private final ContentManager content;
    private final QuestService quests;
    private final Set<UUID> shown = new HashSet<>();

    public SidebarService(ContentManager content, QuestService quests) {
        this.content = content;
        this.quests = quests;
    }

    public void update(Player p) {
        PlayerState s = quests.state(p);
        boolean on = s != null && s.flags.contains("pref:sidebar");
        if (!on) {
            if (shown.remove(p.getUniqueId())) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            return;
        }
        List<String> lines = new ArrayList<>();
        for (Map.Entry<String, QuestProgress> e : s.active.entrySet()) {
            if (!s.tracking(e.getKey())) continue;
            QuestDefinition q = content.quests().get(e.getKey());
            if (q == null) continue;
            lines.add(SECTION + "6" + trim(q.title()));
            for (String l : quests.describe(q, e.getValue())) lines.add(SECTION + "7" + trim(l));
        }
        if (lines.isEmpty()) lines.add(SECTION + "7No tracked quests");
        if (lines.size() > MAX_LINES) lines = lines.subList(0, MAX_LINES);

        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("chronicles", Criteria.DUMMY, Component.text("Quests"));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        int score = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            // Sidebar entries must be unique strings, so each line gets an invisible reset-code suffix.
            obj.getScore(lines.get(i) + (SECTION + "r").repeat(i)).setScore(score--);
        }
        p.setScoreboard(board);
        shown.add(p.getUniqueId());
    }

    public void forget(UUID id) { shown.remove(id); }

    private static String trim(String s) { return s.length() <= 38 ? s : s.substring(0, 37) + "~"; }
}
