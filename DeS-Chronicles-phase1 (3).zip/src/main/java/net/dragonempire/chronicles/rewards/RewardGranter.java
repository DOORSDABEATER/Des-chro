package net.dragonempire.chronicles.rewards;

import java.util.UUID;

/** Applies one reward to a player. Called on the thread given to RewardEngine (the main thread in the plugin). */
public interface RewardGranter {
    void grant(UUID player, RewardSpec reward);
}
