package net.dragonempire.chronicles.rewards;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface ClaimStore {
    /** Completes true exactly once per (player, quest, rewardKey). */
    CompletableFuture<Boolean> claimReward(UUID player, String questId, String rewardKey);
}
