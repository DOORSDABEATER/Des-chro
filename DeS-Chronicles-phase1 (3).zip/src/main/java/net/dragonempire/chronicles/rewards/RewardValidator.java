package net.dragonempire.chronicles.rewards;

import net.dragonempire.chronicles.achievements.AchievementDefinition;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.Material;

import java.util.List;
import java.util.Map;

/** Checks reward parameters so bad config fails at load time, not when a player finishes a quest. */
public final class RewardValidator {
    private RewardValidator() {}

    public static void validate(List<RewardSpec> rewards, String file, String path, Map<String, AchievementDefinition> achievements,
                                boolean checkAchievements, List<ValidationIssue> issues) {
        for (RewardSpec r : rewards) {
            String p = path + "[" + r.key() + "]";
            Map<String, Object> m = r.params();
            switch (r.type()) {
                case "item" -> {
                    if (!(m.get("item") instanceof String it) || Material.matchMaterial(it) == null) {
                        issues.add(new ValidationIssue(file, p + ".item", "must be a valid material name"));
                    }
                    if (m.get("amount") instanceof Number n && n.intValue() < 1) issues.add(new ValidationIssue(file, p + ".amount", "must be >= 1"));
                }
                case "xp" -> {
                    if (!(m.get("amount") instanceof Number n) || n.intValue() < 1) issues.add(new ValidationIssue(file, p + ".amount", "required, >= 1"));
                }
                case "money" -> {
                    if (!(m.get("amount") instanceof Number n) || n.doubleValue() <= 0) issues.add(new ValidationIssue(file, p + ".amount", "required, > 0"));
                }
                case "counter" -> {
                    if (!(m.get("key") instanceof String k) || k.isBlank()) issues.add(new ValidationIssue(file, p + ".key", "required"));
                    if (!(m.get("amount") instanceof Number n) || n.intValue() == 0) issues.add(new ValidationIssue(file, p + ".amount", "required, non-zero"));
                }
                case "global" -> {
                    if (!(m.get("key") instanceof String k) || k.isBlank()) issues.add(new ValidationIssue(file, p + ".key", "required"));
                    if (!(m.get("amount") instanceof Number n) || n.longValue() < 1) issues.add(new ValidationIssue(file, p + ".amount", "required, >= 1"));
                }
                case "command" -> {
                    if (!(m.get("command") instanceof String c) || c.isBlank()) issues.add(new ValidationIssue(file, p + ".command", "required"));
                }
                case "flag" -> {
                    if (!(m.get("flag") instanceof String f) || f.isBlank()) issues.add(new ValidationIssue(file, p + ".flag", "required"));
                }
                case "achievement" -> {
                    if (!(m.get("id") instanceof String id) || id.isBlank()) issues.add(new ValidationIssue(file, p + ".id", "required"));
                    else if (checkAchievements && !achievements.containsKey(id)) issues.add(new ValidationIssue(file, p + ".id", "unknown achievement '" + id + "'"));
                }
                default -> { }
            }
        }
    }
}
