package net.dragonempire.chronicles.content;

import org.bukkit.Location;

/** A named discovery/visit area from locations.yml. */
public record LocationSpec(String name, String world, double x, double y, double z, double radius) {
    public boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        double dx = l.getX() - x, dy = l.getY() - y, dz = l.getZ() - z;
        return dx * dx + dy * dy + dz * dz <= radius * radius;
    }
}
