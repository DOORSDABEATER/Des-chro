package net.dragonempire.chronicles.journal;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.objectives.QuestProgress;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Chest-GUI journal with Active / Available / Completed tabs and paging. Every click is cancelled by the listener. */
public final class QuestJournal {
    public enum Tab { ACTIVE, AVAILABLE, COMPLETED }

    private static final int PER_PAGE = 45;

    /** Identifies journal inventories and remembers which quest sits in which slot. */
    public static final class Holder implements InventoryHolder {
        final Tab tab;
        final int page;
        final List<String> slotQuests = new ArrayList<>();
        Inventory inventory;

        Holder(Tab tab, int page) {
            this.tab = tab;
            this.page = page;
        }

        @Override
        public Inventory getInventory() { return inventory; }
    }

    private final ContentManager content;
    private final QuestService quests;

    private final boolean itemModels;

    /** itemModels: use the deschronicles:* item models from the resource pack (only enable if players load it). */
    public QuestJournal(ContentManager content, QuestService quests, boolean itemModels) {
        this.content = content;
        this.quests = quests;
        this.itemModels = itemModels;
    }

    public void open(Player p, Tab tab, int page) {
        PlayerState s = quests.state(p);
        if (s == null) {
            p.sendMessage(Messages.get("quest.loading"));
            return;
        }
        List<String> ids = new ArrayList<>();
        switch (tab) {
            // A quest whose file was deleted may still be active in a player's saved data: skip it instead of crashing.
            case ACTIVE -> s.active.keySet().stream().filter(id -> content.quests().containsKey(id)).forEach(ids::add);
            case AVAILABLE -> quests.available(s).forEach(q -> ids.add(q.id()));
            case COMPLETED -> s.completions.keySet().stream().filter(id -> content.quests().containsKey(id)).forEach(ids::add);
        }
        ids.sort(String::compareTo);
        int pages = Math.max(1, (ids.size() + PER_PAGE - 1) / PER_PAGE);
        int pg = Math.min(Math.max(0, page), pages - 1);

        Holder h = new Holder(tab, pg);
        Inventory inv = Bukkit.createInventory(h, 54, Messages.get("journal.title." + tab.name().toLowerCase()));
        h.inventory = inv;

        for (int i = 0; i < PER_PAGE && pg * PER_PAGE + i < ids.size(); i++) {
            String id = ids.get(pg * PER_PAGE + i);
            QuestDefinition q = content.quests().get(id);
            h.slotQuests.add(id);
            inv.setItem(i, questItem(tab, q, s));
        }
        inv.setItem(45, nav(Material.BOOK, Messages.plain("journal.nav.active"), tab == Tab.ACTIVE, "journal_active"));
        inv.setItem(46, nav(Material.MAP, Messages.plain("journal.nav.available"), tab == Tab.AVAILABLE, "journal_available"));
        inv.setItem(47, nav(Material.ENCHANTED_BOOK, Messages.plain("journal.nav.completed"), tab == Tab.COMPLETED, "journal_completed"));
        inv.setItem(48, nav(Material.ARROW, Messages.plain("journal.nav.previous"), false, null));
        inv.setItem(49, nav(Material.CLOCK, Messages.plain("journal.nav.refresh", "page", String.valueOf(pg + 1), "pages", String.valueOf(pages)), false, null));
        inv.setItem(50, nav(Material.ARROW, Messages.plain("journal.nav.next"), false, null));
        inv.setItem(53, nav(Material.BARRIER, Messages.plain("journal.nav.close"), false, null));
        p.openInventory(inv);
    }

    public void click(Player p, Holder h, int slot) {
        click(p);
        if (slot >= 0 && slot < h.slotQuests.size()) {
            if (h.tab == Tab.ACTIVE) {
                String id = h.slotQuests.get(slot);
                PlayerState s = quests.state(p);
                if (s != null) quests.setTracked(p, id, !s.tracking(id));
                open(p, h.tab, h.page);
            }
            return;
        }
        switch (slot) {
            case 45 -> open(p, Tab.ACTIVE, 0);
            case 46 -> open(p, Tab.AVAILABLE, 0);
            case 47 -> open(p, Tab.COMPLETED, 0);
            case 48 -> open(p, h.tab, h.page - 1);
            case 49 -> open(p, h.tab, h.page);
            case 50 -> open(p, h.tab, h.page + 1);
            case 53 -> p.closeInventory();
            default -> { }
        }
    }

    private ItemStack questItem(Tab tab, QuestDefinition q, PlayerState s) {
        Material icon = switch (tab) {
            case ACTIVE -> Material.WRITABLE_BOOK;
            case AVAILABLE -> Material.PAPER;
            case COMPLETED -> Material.WRITTEN_BOOK;
        };
        List<Component> lore = new ArrayList<>();
        for (String line : wrap(q.description(), 40)) lore.add(plain(line, NamedTextColor.GRAY));
        if (!q.giver().isBlank()) lore.add(plain(Messages.plain("journal.giver", "giver", q.giver()), NamedTextColor.DARK_AQUA));
        if (tab == Tab.ACTIVE) {
            QuestProgress prog = s.active.get(q.id());
            lore.add(Component.empty());
            for (String line : quests.describe(q, prog)) lore.add(plain(line, NamedTextColor.WHITE));
            lore.add(Component.empty());
            lore.add(plain(Messages.plain(s.tracking(q.id()) ? "journal.tracked" : "journal.track"), NamedTextColor.YELLOW));
        } else if (tab == Tab.COMPLETED) {
            lore.add(plain(Messages.plain("journal.completed", "count", String.valueOf(s.completions.getOrDefault(q.id(), 1))), NamedTextColor.GREEN));
        }
        return item(icon, plain(q.title(), NamedTextColor.GOLD), lore, "journal_" + tab.name().toLowerCase());
    }

    private ItemStack nav(Material m, String name, boolean selected, String model) {
        return item(m, plain(name + (selected ? " (selected)" : ""), selected ? NamedTextColor.GOLD : NamedTextColor.YELLOW), List.of(), model);
    }

    private ItemStack item(Material m, Component name, List<Component> lore, String model) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name);
        meta.lore(lore);
        if (itemModels && model != null) meta.setItemModel(NamespacedKey.fromString("deschronicles:" + model));
        it.setItemMeta(meta);
        return it;
    }

    private static Component plain(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static List<String> wrap(String text, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : text.split("\\s+")) {
            if (w.isEmpty()) continue;
            if (cur.length() + w.length() + 1 > width && cur.length() > 0) {
                out.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void click(Player p) {
        p.playSound(Sound.sound(Key.key("minecraft:ui.button.click"), Sound.Source.MASTER, 0.6f, 1f));
    }
}
