package net.dragonempire.chronicles.dialogue;

import net.dragonempire.chronicles.condition.ConditionContext;

import java.util.ArrayList;
import java.util.List;

/** One player's conversation state. Pure logic: rendering and animation live elsewhere. */
public final class DialogueSession {
    public record ChoiceResult(List<DialogueAction> actions, boolean ended) {}

    private final DialogueDefinition def;
    private final ConditionContext ctx;
    private final List<String> history = new ArrayList<>();
    private DialogueNode node;
    private int page;
    private boolean ended;

    public DialogueSession(DialogueDefinition def, ConditionContext ctx) {
        this.def = def;
        this.ctx = ctx;
        this.node = def.nodes().get(def.resolveStart(ctx));
    }

    public DialogueDefinition definition() { return def; }
    public DialogueNode node() { return node; }
    public boolean ended() { return ended; }
    /** Choice ids picked so far, in order. */
    public List<String> history() { return List.copyOf(history); }
    public List<DialogueAction> enterActions() { return node.onEnter(); }

    public String pageText() { return node.pages().get(page); }
    public boolean hasMorePages() { return page < node.pages().size() - 1; }

    /** Advance one page. After the last page of a choiceless node the session ends. */
    public void advance() {
        if (ended) return;
        if (hasMorePages()) {
            page++;
        } else if (visibleChoices().isEmpty()) {
            ended = true;
        }
    }

    /** Choices are only offered once all pages have been read. */
    public List<DialogueChoice> visibleChoices() {
        if (ended || hasMorePages()) return List.of();
        return node.choices().stream().filter(c -> c.condition().test(ctx)).toList();
    }

    public ChoiceResult choose(int index) {
        List<DialogueChoice> vis = visibleChoices();
        if (index < 0 || index >= vis.size()) throw new IllegalArgumentException("no visible choice at " + index);
        DialogueChoice c = vis.get(index);
        history.add(c.id());
        if (c.next() == null) {
            ended = true;
        } else {
            node = def.nodes().get(c.next());
            page = 0;
        }
        return new ChoiceResult(c.actions(), ended);
    }

    /** Interruption: the session simply ends; history so far remains valid. */
    public void interrupt() { ended = true; }
}
