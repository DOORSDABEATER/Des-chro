package net.dragonempire.chronicles.dialogue;

import net.dragonempire.chronicles.condition.Condition;

import java.util.List;

/** next == null means the conversation ends after this choice. */
public record DialogueChoice(String id, String text, Condition condition, String next, List<DialogueAction> actions) {}
