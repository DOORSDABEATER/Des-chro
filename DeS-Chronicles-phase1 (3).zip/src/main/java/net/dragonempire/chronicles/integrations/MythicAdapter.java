package net.dragonempire.chronicles.integrations;

import net.dragonempire.chronicles.bosses.BossManager;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Optional MythicMobs integration through reflection (no compile dependency). When a Mythic mob dies, the killer is
 * credited with the boss whose `external.mythic` matches the mob type. Mythic does not report damage contributions
 * here, so only the killer is credited; use "/desquests boss credit" from a Mythic skill to credit a whole group.
 */
public final class MythicAdapter implements Listener {
    private static final String EVENT = "io.lumine.mythic.bukkit.events.MythicMobDeathEvent";

    private MythicAdapter() {}

    public static void register(JavaPlugin plugin, BossManager bosses) {
        Class<? extends Event> type;
        try {
            type = Class.forName(EVENT).asSubclass(Event.class);
        } catch (ClassNotFoundException e) {
            return; // MythicMobs not installed
        }
        plugin.getServer().getPluginManager().registerEvent(type, new MythicAdapter(), EventPriority.MONITOR, (listener, event) -> {
            try {
                Object mobType = event.getClass().getMethod("getMobType").invoke(event);
                String name = String.valueOf(mobType.getClass().getMethod("getInternalName").invoke(mobType));
                Object killer = event.getClass().getMethod("getKiller").invoke(event);
                if (killer instanceof Entity k) bosses.onExternalKill(name, k);
            } catch (ReflectiveOperationException | ClassCastException e) {
                plugin.getLogger().warning("MythicMobs adapter could not read the death event (API mismatch?): " + e);
            }
        }, plugin);
        plugin.getLogger().info("MythicMobs detected: bosses with external.mythic are now credited on kill.");
    }
}
