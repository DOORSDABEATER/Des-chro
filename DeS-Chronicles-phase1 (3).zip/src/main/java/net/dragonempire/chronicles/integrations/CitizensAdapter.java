package net.dragonempire.chronicles.integrations;

import net.dragonempire.chronicles.npc.NpcManager;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Optional Citizens integration without a compile dependency: listens for NPCRightClickEvent through reflection and
 * routes it to the external NPC whose `citizens_id` matches. Citizens supplies the skin and body; this plugin supplies
 * dialogue, quests and objectives. If Citizens is absent or its API differs, this logs once and does nothing.
 */
public final class CitizensAdapter implements Listener {
    private static final String EVENT = "net.citizensnpcs.api.event.NPCRightClickEvent";

    private CitizensAdapter() {}

    public static void register(JavaPlugin plugin, NpcManager npcs) {
        Class<? extends Event> type;
        try {
            type = Class.forName(EVENT).asSubclass(Event.class);
        } catch (ClassNotFoundException e) {
            return; // Citizens not installed: nothing to do
        }
        plugin.getServer().getPluginManager().registerEvent(type, new CitizensAdapter(), EventPriority.NORMAL, (listener, event) -> {
            try {
                Object npc = event.getClass().getMethod("getNPC").invoke(event);
                int id = ((Number) npc.getClass().getMethod("getId").invoke(npc)).intValue();
                Object clicker = event.getClass().getMethod("getClicker").invoke(event);
                if (clicker instanceof Player p) npcs.talkByCitizensId(p, id);
            } catch (ReflectiveOperationException | ClassCastException e) {
                plugin.getLogger().warning("Citizens adapter could not read the click event (API mismatch?): " + e);
            }
        }, plugin);
        plugin.getLogger().info("Citizens detected: NPCs with provider 'external' and a citizens_id are now connected.");
    }
}
