package net.dragonempire.chronicles.integrations;

import net.dragonempire.chronicles.npc.SkinSpec;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.logging.Level;

/**
 * Player-like NPCs with custom skins and no Citizens: uses the vanilla Mannequin entity. The skin, immovability and the
 * hidden "NPC" description are set through Paper's Mannequin API (found by reflection so this plugin still loads on
 * servers without it). If any API call fails, the same settings are applied with the vanilla `data merge entity` command.
 * If neither works, a warning is logged and the mannequin keeps its default look.
 */
public final class MannequinSupport {
    private MannequinSupport() {}

    public static boolean isMannequin(Entity e) {
        return e.getType().name().equals("MANNEQUIN");
    }

    public static void apply(JavaPlugin plugin, Entity e, SkinSpec skin) {
        if (!isMannequin(e)) return;
        if (applyViaApi(plugin, e, skin)) return;
        String cmd = "data merge entity " + e.getUniqueId() + " " + (skin != null ? skin.toNbt() : "{immovable:1b,hide_description:1b}");
        plugin.getLogger().info("Mannequin API not usable here; applying settings with: /" + cmd.substring(0, Math.min(cmd.length(), 90)) + "...");
        if (!Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd)) {
            plugin.getLogger().warning("Could not apply the mannequin skin/settings by command either; it will use the default look.");
        }
    }

    private static boolean applyViaApi(JavaPlugin plugin, Entity e, SkinSpec skin) {
        try {
            Class<?> mannequin = Class.forName("org.bukkit.entity.Mannequin");
            if (!mannequin.isInstance(e)) return false;
            mannequin.getMethod("setImmovable", boolean.class).invoke(e, true);
            mannequin.getMethod("setHideDescription", boolean.class).invoke(e, true);
            if (skin != null) {
                Class<?> profileType = Class.forName("io.papermc.paper.datacomponent.item.ResolvableProfile");
                Class<?> builderType = Class.forName("io.papermc.paper.datacomponent.item.ResolvableProfile$Builder");
                Object builder = profileType.getMethod("resolvableProfile").invoke(null);
                if (skin.byPlayer()) {
                    builderType.getMethod("name", String.class).invoke(builder, skin.player());
                } else {
                    Class<?> propType = Class.forName("com.destroystokyo.paper.profile.ProfileProperty");
                    Object prop = propType.getConstructor(String.class, String.class, String.class)
                            .newInstance("textures", skin.value(), skin.signature().isEmpty() ? null : skin.signature());
                    builderType.getMethod("addProperty", propType).invoke(builder, prop);
                }
                Object profile = builderType.getMethod("build").invoke(builder);
                Method set = mannequin.getMethod("setProfile", profileType);
                set.invoke(e, profile);
            }
            return true;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
            plugin.getLogger().log(Level.FINE, "Mannequin API call failed, falling back to NBT: " + ex);
            return false;
        }
    }
}
