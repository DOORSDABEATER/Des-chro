package net.dragonempire.chronicles.objectives;

/** Counts how many items a crafting click produces. Pure logic so it can be tested. */
public final class CraftMath {
    private CraftMath() {}

    /**
     * A shift-click crafts repeatedly until an ingredient runs out, so the number of crafts is the smallest non-empty
     * ingredient stack. A normal click is exactly one craft. Result is crafts times the recipe's output amount.
     * (Inventory space can cut a shift-click short; this is an upper bound, which is the safe side for a single click.)
     */
    public static int produced(boolean shiftClick, int[] ingredientAmounts, int resultAmount) {
        int perCraft = Math.max(1, resultAmount);
        if (!shiftClick) return perCraft;
        int crafts = Integer.MAX_VALUE;
        for (int a : ingredientAmounts) if (a > 0) crafts = Math.min(crafts, a);
        return crafts == Integer.MAX_VALUE ? perCraft : crafts * perCraft;
    }
}
