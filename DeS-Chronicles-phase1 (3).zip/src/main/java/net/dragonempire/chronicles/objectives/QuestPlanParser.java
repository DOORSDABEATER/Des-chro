package net.dragonempire.chronicles.objectives;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

/**
 * Parses `stages:` (or a flat `objectives:` list, treated as one stage) from a quest document.
 * Stage keys: title, mode (sequential|parallel, default sequential), required, objectives.
 * Objective keys: id, type, target, amount, optional, hidden, description.
 */
public final class QuestPlanParser {
    private QuestPlanParser() {}

    public static QuestPlan parse(Map<String, Object> root, String file, List<ValidationIssue> issues) {
        int before = issues.size();
        List<Object> rawStages = new ArrayList<>();
        if (root.get("stages") instanceof List<?> sl) {
            rawStages.addAll(sl);
        } else if (root.get("objectives") instanceof List<?> ol) {
            rawStages.add(Map.of("objectives", ol));
        }
        if (rawStages.isEmpty()) {
            issues.add(new ValidationIssue(file, "stages", "at least one stage or objective required"));
            return null;
        }
        Set<String> ids = new HashSet<>();
        List<StageSpec> stages = new ArrayList<>();
        for (int s = 0; s < rawStages.size(); s++) {
            String sp = "stages[" + s + "]";
            if (!(rawStages.get(s) instanceof Map<?, ?> sm)) {
                issues.add(new ValidationIssue(file, sp, "must be a map"));
                continue;
            }
            String mode = sm.get("mode") instanceof String m ? m.toLowerCase(Locale.ROOT) : "sequential";
            if (!mode.equals("sequential") && !mode.equals("parallel")) {
                issues.add(new ValidationIssue(file, sp + ".mode", "must be sequential or parallel"));
                continue;
            }
            List<ObjectiveSpec> objs = new ArrayList<>();
            if (sm.get("objectives") instanceof List<?> ol) {
                for (int o = 0; o < ol.size(); o++) {
                    String op = sp + ".objectives[" + o + "]";
                    if (!(ol.get(o) instanceof Map<?, ?> om) || !(om.get("type") instanceof String type) || type.isBlank()) {
                        issues.add(new ValidationIssue(file, op + ".type", "required"));
                        continue;
                    }
                    String id = om.get("id") instanceof String i ? i : "s" + s + "o" + o;
                    if (!ids.add(id)) {
                        issues.add(new ValidationIssue(file, op + ".id", "duplicate objective id '" + id + "'"));
                        continue;
                    }
                    int amount = om.get("amount") instanceof Number n ? n.intValue() : 1;
                    if (amount < 1) {
                        issues.add(new ValidationIssue(file, op + ".amount", "must be >= 1"));
                        continue;
                    }
                    String target = om.get("target") instanceof String t ? t
                            : om.get("npc") instanceof String t ? t
                            : om.get("item") instanceof String t ? t : null;
                    objs.add(new ObjectiveSpec(id, type.toUpperCase(Locale.ROOT), target, amount,
                            Boolean.TRUE.equals(om.get("optional")), Boolean.TRUE.equals(om.get("hidden")),
                            om.get("description") instanceof String d ? d : "", Boolean.TRUE.equals(om.get("reset_on_death"))));
                }
            }
            int nonOptional = (int) objs.stream().filter(x -> !x.optional()).count();
            if (nonOptional == 0) {
                issues.add(new ValidationIssue(file, sp + ".objectives", "needs at least one non-optional objective"));
                continue;
            }
            int required = nonOptional;
            if (sm.get("required") instanceof Number n) {
                required = n.intValue();
                if (required < 1 || required > nonOptional) {
                    issues.add(new ValidationIssue(file, sp + ".required", "must be between 1 and " + nonOptional));
                    continue;
                }
            }
            stages.add(new StageSpec(sm.get("title") instanceof String t ? t : "", mode.equals("sequential"),
                    required, List.copyOf(objs)));
        }
        if (issues.size() > before) return null;
        return new QuestPlan(List.copyOf(stages));
    }
}
