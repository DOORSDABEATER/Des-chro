package net.dragonempire.chronicles.objectives;

import java.util.List;

public record QuestPlan(List<StageSpec> stages) {}
