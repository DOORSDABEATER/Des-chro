package net.dragonempire.chronicles.objectives;

import java.util.List;

public record ProgressResult(List<String> changedObjectives, boolean stageAdvanced, boolean questCompleted) {
    public static final ProgressResult NONE = new ProgressResult(List.of(), false, false);
    public boolean changed() { return !changedObjectives.isEmpty(); }
}
