package net.dragonempire.chronicles.bosses;

import java.util.*;

/** Damage dealt per player. Only players at or above minDamage count as participants. */
public final class ContributionTracker {
    private final Map<UUID, Double> damage = new LinkedHashMap<>();

    public void add(UUID player, double amount) {
        if (amount > 0) damage.merge(player, amount, Double::sum);
    }

    public double of(UUID player) { return damage.getOrDefault(player, 0.0); }

    public List<UUID> qualified(double minDamage) {
        List<UUID> out = new ArrayList<>();
        for (Map.Entry<UUID, Double> e : damage.entrySet()) if (e.getValue() >= minDamage && e.getValue() > 0) out.add(e.getKey());
        return out;
    }

    public Set<UUID> all() { return Collections.unmodifiableSet(damage.keySet()); }
}
