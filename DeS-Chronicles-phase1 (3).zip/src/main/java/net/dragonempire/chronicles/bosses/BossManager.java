package net.dragonempire.chronicles.bosses;

import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.objectives.ObjectiveEvent;
import net.dragonempire.chronicles.parties.PartyManager;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Vanilla-entity boss encounters. Quests never depend on a boss plugin: they listen for the KILL_BOSS objective,
 * which this manager fires only for players who dealt at least min_damage and were inside the arena at the kill.
 * Instanced bosses (`instanced: true`) belong to one party: other players cannot see or damage them, and each party
 * can run its own copy at the same time. External bosses (MythicMobs etc.) are spawned by a console command and
 * credited through the adapter or "/desquests boss credit".
 */
public final class BossManager {
    private static final class Active {
        final String key;
        final BossDefinition def;
        final UUID entity;
        final Set<UUID> members; // null for shared (non-instanced) bosses
        final ContributionTracker tracker = new ContributionTracker();
        final Set<Integer> firedPhases = new HashSet<>();
        BukkitTask timeout;

        Active(String key, BossDefinition def, UUID entity, Set<UUID> members) {
            this.key = key;
            this.def = def;
            this.entity = entity;
            this.members = members;
        }
    }

    private final JavaPlugin plugin;
    private final ContentManager content;
    private final QuestService quests;
    private final ActionExecutor actions;
    private final NamespacedKey key;
    private final Map<String, Active> byKey = new HashMap<>();
    private final Map<UUID, Active> byEntity = new HashMap<>();
    private PartyManager parties;

    public BossManager(JavaPlugin plugin, ContentManager content, QuestService quests, ActionExecutor actions) {
        this.plugin = plugin;
        this.content = content;
        this.quests = quests;
        this.actions = actions;
        this.key = new NamespacedKey(plugin, "boss_id");
    }

    public NamespacedKey key() { return key; }
    public void setParties(PartyManager parties) { this.parties = parties; }

    /** Returns null on success or a reason it could not spawn. */
    public String spawn(String id, Player starter) {
        BossDefinition def = content.bosses().get(id);
        if (def == null) return "Unknown boss: " + id;
        if (!def.configured()) return "This encounter has not been set up on the server yet (boss '" + id + "' is unconfigured).";
        if (!def.externalSpawnCommand().isBlank()) {
            String cmd = def.externalSpawnCommand().replace("{world}", def.world()).replace("{x}", String.valueOf(def.x()))
                    .replace("{y}", String.valueOf(def.y())).replace("{z}", String.valueOf(def.z()));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return null; // the external plugin owns this boss; kills arrive through its adapter or "boss credit"
        }
        Set<UUID> members = null;
        String instanceKey = id;
        if (def.instanced()) {
            if (starter == null) return "Instanced bosses need a player to own the encounter.";
            members = new HashSet<>(parties == null ? Set.of(starter.getUniqueId()) : parties.membersOf(starter.getUniqueId()));
            UUID leader = members.stream().min(Comparator.comparing(UUID::toString)).orElse(starter.getUniqueId());
            instanceKey = id + "#" + leader;
        }
        World w = Bukkit.getWorld(def.world());
        if (w == null) return "Boss world '" + def.world() + "' is not loaded.";
        Active existing = byKey.get(instanceKey);
        if (existing != null) {
            Entity old = Bukkit.getEntity(existing.entity);
            if (old != null && old.isValid()) return "That encounter is already in progress.";
            drop(existing); // stale: entity was lost (e.g. chunk unloaded)
        }
        Entity e = w.spawnEntity(new Location(w, def.x(), def.y(), def.z()), EntityType.valueOf(def.entity()));
        e.setPersistent(false);
        e.customName(MiniMessage.miniMessage().deserialize(def.name()));
        e.setCustomNameVisible(true);
        e.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        if (e instanceof LivingEntity le) {
            AttributeInstance max = le.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) max.setBaseValue(def.health());
            le.setHealth(Math.min(def.health(), max == null ? def.health() : max.getValue()));
            le.setRemoveWhenFarAway(false);
        }
        Active a = new Active(instanceKey, def, e.getUniqueId(), members);
        if (def.timeLimitSeconds() > 0) {
            a.timeout = plugin.getServer().getScheduler().runTaskLater(plugin, () -> expire(a), def.timeLimitSeconds() * 20L);
        }
        byKey.put(instanceKey, a);
        byEntity.put(e.getUniqueId(), a);
        if (members != null) for (Player online : Bukkit.getOnlinePlayers()) refreshVisibility(online);
        return null;
    }

    /** Hides instanced encounters from players who are not part of them. Call on join and after spawns. */
    public void refreshVisibility(Player p) {
        for (Active a : byEntity.values()) {
            if (a.members == null) continue;
            Entity e = Bukkit.getEntity(a.entity);
            if (e == null || !e.isValid()) continue;
            if (a.members.contains(p.getUniqueId())) p.showEntity(plugin, e);
            else p.hideEntity(plugin, e);
        }
    }

    /** False if this is an instanced boss that the player is not a member of. */
    public boolean canDamage(Entity victim, Player attacker) {
        Active a = byEntity.get(victim.getUniqueId());
        return a == null || a.members == null || a.members.contains(attacker.getUniqueId());
    }

    public void onDamage(Entity victim, Player attacker, double finalDamage) {
        Active a = byEntity.get(victim.getUniqueId());
        if (a == null) return;
        a.tracker.add(attacker.getUniqueId(), finalDamage);
        if (!(victim instanceof LivingEntity le)) return;
        AttributeInstance max = le.getAttribute(Attribute.MAX_HEALTH);
        double fraction = Math.max(0, le.getHealth() - finalDamage) / (max == null ? a.def.health() : max.getValue());
        for (int i = 0; i < a.def.phases().size(); i++) {
            BossPhase phase = a.def.phases().get(i);
            if (fraction <= phase.below() && a.firedPhases.add(i)) {
                for (UUID u : a.tracker.all()) {
                    Player p = Bukkit.getPlayer(u);
                    if (p != null && p.getWorld().equals(victim.getWorld())
                            && p.getLocation().distanceSquared(victim.getLocation()) <= a.def.arenaRadius() * a.def.arenaRadius()) {
                        actions.run(p, phase.actions());
                    }
                }
            }
        }
    }

    public void onDeath(Entity victim) {
        Active a = byEntity.get(victim.getUniqueId());
        if (a == null) return;
        drop(a);
        Location at = victim.getLocation();
        for (UUID u : a.tracker.qualified(a.def.minDamage())) {
            if (a.members != null && !a.members.contains(u)) continue;
            Player p = Bukkit.getPlayer(u);
            if (p == null || !p.getWorld().equals(at.getWorld())) continue;
            if (p.getLocation().distanceSquared(at) > a.def.arenaRadius() * a.def.arenaRadius()) continue; // left the arena
            quests.addFlag(p, "boss:" + a.def.id());
            quests.handle(p, new ObjectiveEvent("KILL_BOSS", a.def.id()));
            p.sendMessage(Messages.get("boss.helped", "boss", Messages.stripTags(a.def.name())));
        }
    }

    /** MythicMobs adapter: credits the killer of a mob whose type matches a boss definition's `external.mythic`. */
    public void onExternalKill(String mobType, Entity killer) {
        if (!(killer instanceof Player p)) return;
        for (BossDefinition def : content.bosses().values()) {
            if (!def.mythic().isBlank() && def.mythic().equalsIgnoreCase(mobType)) {
                credit(p, def.id());
                p.sendMessage(Messages.get("boss.defeated", "boss", Messages.stripTags(def.name())));
            }
        }
    }

    /**
     * For external boss plugins (for example a MythicMobs skill running "/desquests boss credit <id> <player>"):
     * grants the same credit as a normal kill. The external system is responsible for judging participation.
     */
    public String credit(Player p, String id) {
        if (!content.bosses().containsKey(id)) return "Unknown boss: " + id;
        quests.addFlag(p, "boss:" + id);
        quests.handle(p, new ObjectiveEvent("KILL_BOSS", id));
        return null;
    }

    private void expire(Active a) {
        if (byEntity.get(a.entity) != a) return;
        drop(a);
        Entity e = Bukkit.getEntity(a.entity);
        if (e != null) e.remove();
        for (UUID u : a.tracker.all()) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) p.sendMessage(Messages.get("boss.timeout"));
        }
    }

    private void drop(Active a) {
        if (a.timeout != null) a.timeout.cancel();
        byKey.remove(a.key);
        byEntity.remove(a.entity);
    }

    public void despawnAll() {
        for (Active a : new ArrayList<>(byEntity.values())) {
            drop(a);
            Entity e = Bukkit.getEntity(a.entity);
            if (e != null) e.remove();
        }
    }
}
