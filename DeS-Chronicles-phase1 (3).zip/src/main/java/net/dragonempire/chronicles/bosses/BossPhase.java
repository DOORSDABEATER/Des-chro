package net.dragonempire.chronicles.bosses;

import net.dragonempire.chronicles.dialogue.DialogueAction;

import java.util.List;

/** Fires once when the boss's health fraction drops to or below `below`. */
public record BossPhase(double below, List<DialogueAction> actions) {}
