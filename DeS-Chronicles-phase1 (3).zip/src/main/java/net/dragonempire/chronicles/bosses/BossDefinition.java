package net.dragonempire.chronicles.bosses;

import java.util.List;

/**
 * externalSpawnCommand: if set, spawning runs this console command ({world} {x} {y} {z} are filled in) instead of
 * spawning a vanilla entity, and kills are credited by the MythicMobs adapter when `mythic` matches the mob type.
 * instanced=true: each party gets a private copy of the encounter; others cannot see or hit it.
 * configured=false means the spawn location is still a placeholder: the boss refuses to spawn. */
public record BossDefinition(String id, String name, String entity, boolean configured, String world,
                             double x, double y, double z, double health, double arenaRadius,
                             int timeLimitSeconds, double minDamage, List<BossPhase> phases,
                             String externalSpawnCommand, String mythic, boolean instanced) {}
