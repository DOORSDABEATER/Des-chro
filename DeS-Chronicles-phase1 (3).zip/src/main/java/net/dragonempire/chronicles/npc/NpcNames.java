package net.dragonempire.chronicles.npc;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * The id is a permanent technical key (lowercase letters, digits, underscore). The display name is separate,
 * free text with optional MiniMessage formatting, so an NPC with id "ancient_one" can be shown as "Ancient One".
 */
public final class NpcNames {
    private static final Pattern VALID_ID = Pattern.compile("[a-z0-9_]{2,32}");

    private NpcNames() {}

    /** "Ancient One" or "Ancient-One" becomes "ancient_one"; anything else unusable is dropped. */
    public static String normalizeId(String raw) {
        String s = raw.trim().toLowerCase(Locale.ROOT).replaceAll("[\\s-]+", "_").replaceAll("[^a-z0-9_]", "");
        return s.replaceAll("_+", "_");
    }

    public static boolean validId(String id) { return VALID_ID.matcher(id).matches(); }

    /** "ancient_one" becomes "Ancient One". */
    public static String prettify(String id) {
        StringBuilder sb = new StringBuilder();
        for (String part : id.split("_+")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
