package net.dragonempire.chronicles.npc;

import net.dragonempire.chronicles.condition.Condition;

import java.util.List;

/**
 * name is the display name (MiniMessage); id is the permanent key. showName=false hides the floating name (secret NPCs).
 * skin (nullable) is applied to Mannequin NPCs: no Citizens needed for custom skins.
 * behavior: stationary | patrol | guard | hostile.
 *  - guard: the mob keeps its AI (an iron golem fights monsters) but is invulnerable and is pulled back to its post
 *    when it strays further than guardRadius.
 *  - hostile: vulnerable, keeps its AI and health, fires KILL_NPC when killed and respawns after respawnSeconds (0 = never).
 * external=true means no entity is spawned by this plugin (a Citizens NPC calls "/desquests npc talk", or is matched
 * by citizensId). visibleIf is only consulted when conditional is true.
 */
public record NpcDefinition(String id, String name, String entity, String world, double x, double y, double z,
                            float yaw, float pitch, String dialogue, double interactDistance, String permission,
                            boolean external, boolean lookAtPlayers, double patrolSpeed, List<double[]> patrol,
                            boolean conditional, Condition visibleIf, List<ShopItem> shop,
                            String behavior, double health, int respawnSeconds, double guardRadius, int citizensId,
                            boolean showName, SkinSpec skin) {

    public NpcDefinition withLocation(String world, double x, double y, double z, float yaw, float pitch) {
        return new NpcDefinition(id, name, entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop, behavior, health, respawnSeconds, guardRadius, citizensId, showName, skin);
    }

    public NpcDefinition withDialogue(String dialogue) {
        return new NpcDefinition(id, name, entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop, behavior, health, respawnSeconds, guardRadius, citizensId, showName, skin);
    }

    public NpcDefinition withName(String name) {
        return new NpcDefinition(id, name, entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop, behavior, health, respawnSeconds, guardRadius, citizensId, showName, skin);
    }

    public NpcDefinition withShowName(boolean showName) {
        return new NpcDefinition(id, name, entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop, behavior, health, respawnSeconds, guardRadius, citizensId, showName, skin);
    }

    /** A skin switches the NPC to a Mannequin; clearing it (null) keeps the current entity type. */
    public NpcDefinition withSkin(SkinSpec skin) {
        return new NpcDefinition(id, name, skin != null ? "MANNEQUIN" : entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop, behavior, health, respawnSeconds, guardRadius, citizensId, showName, skin);
    }

    public boolean hostile() { return behavior.equals("hostile"); }
    public boolean guard() { return behavior.equals("guard"); }

    public boolean hasBehavior() { return !external && (lookAtPlayers || !patrol.isEmpty() || guard()); }
}
