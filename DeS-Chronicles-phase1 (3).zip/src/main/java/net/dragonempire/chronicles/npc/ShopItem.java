package net.dragonempire.chronicles.npc;

/** One merchant offer: the player pays `price` (Vault economy) for `amount` of `item`. */
public record ShopItem(String item, int amount, double price) {}
