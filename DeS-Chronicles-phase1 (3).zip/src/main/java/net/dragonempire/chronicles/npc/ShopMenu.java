package net.dragonempire.chronicles.npc;

import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.rewards.EconomyBridge;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Merchant GUI. Prices are charged through the optional Vault economy. Every click is cancelled by ShopListener. */
public final class ShopMenu {
    public static final class Holder implements InventoryHolder {
        final String npcId;
        Inventory inventory;

        Holder(String npcId) { this.npcId = npcId; }

        @Override
        public Inventory getInventory() { return inventory; }
    }

    private final NpcManager npcs;

    public ShopMenu(NpcManager npcs) {
        this.npcs = npcs;
    }

    public void open(Player p, String npcId) {
        NpcDefinition d = npcs.get(npcId);
        if (d == null || d.shop().isEmpty()) {
            p.sendMessage(Messages.get("shop.empty"));
            return;
        }
        Holder h = new Holder(npcId);
        Inventory inv = Bukkit.createInventory(h, 54, MiniMessage.miniMessage().deserialize(d.name()));
        h.inventory = inv;
        for (int i = 0; i < d.shop().size() && i < 45; i++) {
            ShopItem s = d.shop().get(i);
            Material m = Material.matchMaterial(s.item());
            if (m == null) continue; // validated at load; skip defensively
            ItemStack it = new ItemStack(m, s.amount());
            ItemMeta meta = it.getItemMeta();
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text("Price: " + format(s.price()), NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Click to buy", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }
        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta cm = close.getItemMeta();
        cm.displayName(Component.text("Close", NamedTextColor.RED).decoration(TextDecoration.ITALIC, false));
        close.setItemMeta(cm);
        inv.setItem(53, close);
        p.openInventory(inv);
    }

    public void click(Player p, Holder h, int slot) {
        if (slot == 53) {
            p.closeInventory();
            return;
        }
        NpcDefinition d = npcs.get(h.npcId);
        if (d == null || slot < 0 || slot >= d.shop().size() || slot >= 45) return;
        ShopItem s = d.shop().get(slot);
        Material m = Material.matchMaterial(s.item());
        if (m == null) return;
        if (!EconomyBridge.available()) {
            p.sendMessage(Messages.get("shop.noeconomy"));
            return;
        }
        String err = EconomyBridge.withdraw(p, s.price());
        if (err != null) {
            p.sendMessage(Messages.get("shop.failed", "reason", err));
            return;
        }
        for (ItemStack left : p.getInventory().addItem(new ItemStack(m, s.amount())).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
        p.sendMessage(Messages.get("shop.bought", "amount", String.valueOf(s.amount()), "item", m.name().toLowerCase().replace('_', ' '), "price", format(s.price())));
    }

    private static String format(double price) {
        return price == Math.floor(price) ? String.valueOf((long) price) : String.format("%.2f", price);
    }
}
