package net.dragonempire.chronicles.npc;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * A skin for a Mannequin NPC: either a player name (the server resolves it), or a raw texture `value` (with an optional
 * `signature`) as produced by services like mineskin.org, which allows fully custom skins without any account.
 * Inputs are strictly validated because they are placed into a server command as a fallback.
 */
public record SkinSpec(String player, String value, String signature) {
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final Pattern B64 = Pattern.compile("[A-Za-z0-9+/=]{8,}");

    public boolean byPlayer() { return !player.isEmpty(); }

    /** null if raw is null (no skin) or invalid (an issue is added). */
    public static SkinSpec parse(Object raw, String file, String path, List<ValidationIssue> issues) {
        if (raw == null) return null;
        if (!(raw instanceof Map<?, ?> m)) {
            issues.add(new ValidationIssue(file, path, "must be a map with player, or value (+ optional signature)"));
            return null;
        }
        String player = m.get("player") instanceof String s ? s : "";
        String value = m.get("value") instanceof String s ? s : "";
        String signature = m.get("signature") instanceof String s ? s : "";
        if (!player.isEmpty()) {
            if (!NAME.matcher(player).matches()) {
                issues.add(new ValidationIssue(file, path + ".player", "must be a valid Minecraft username (letters, digits, underscore, max 16)"));
                return null;
            }
            return new SkinSpec(player, "", "");
        }
        if (value.isEmpty() || !B64.matcher(value).matches() || (!signature.isEmpty() && !B64.matcher(signature).matches())) {
            issues.add(new ValidationIssue(file, path, "needs player, or a base64 texture value (and optionally its signature)"));
            return null;
        }
        return new SkinSpec("", value, signature);
    }

    /** SNBT for `data merge entity`, used as a fallback when the Paper API call is unavailable. */
    public String toNbt() {
        String profile;
        if (byPlayer()) {
            profile = "{name:\"" + player + "\"}";
        } else {
            profile = "{properties:[{name:\"textures\",value:\"" + value + "\"" + (signature.isEmpty() ? "" : ",signature:\"" + signature + "\"") + "}]}";
        }
        return "{immovable:1b,hide_description:1b,profile:" + profile + "}";
    }
}
