package net.dragonempire.chronicles.cutscenes;

import java.util.List;

/** shared: also plays for eligible players within radius of the trigger. duration is in ticks. */
public record CutsceneDefinition(String id, boolean skippable, boolean shared, double radius, int duration,
                                 List<CutsceneStep> steps) {}
