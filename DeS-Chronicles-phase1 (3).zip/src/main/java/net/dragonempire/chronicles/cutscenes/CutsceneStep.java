package net.dragonempire.chronicles.cutscenes;

import java.util.Map;

/** at = tick offset from the scene start. essential steps still run if the player skips the scene. */
public record CutsceneStep(int at, String type, boolean essential, Map<String, Object> params) {}
