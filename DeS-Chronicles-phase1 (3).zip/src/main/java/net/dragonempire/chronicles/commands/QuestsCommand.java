package net.dragonempire.chronicles.commands;

import net.dragonempire.chronicles.community.CommunityManager;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.hud.MarkerService;
import net.dragonempire.chronicles.hud.SidebarService;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.storage.Database;
import org.bukkit.plugin.java.JavaPlugin;
import net.dragonempire.chronicles.cutscenes.CutsceneManager;
import net.dragonempire.chronicles.parties.PartyManager;
import net.dragonempire.chronicles.questline.QuestlineService;
import org.bukkit.Bukkit;
import net.dragonempire.chronicles.dialogue.DialogueManager;
import net.dragonempire.chronicles.journal.QuestJournal;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Player command. "dialogue" is used by the clickable chat lines and is not meant to be typed. */
public final class QuestsCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of("active", "available", "completed", "journal", "track", "untrack", "abandon", "questlines", "achievements", "reputation", "community", "recommend", "top", "markers", "sidebar", "party", "skip", "help");

    private final QuestService quests;
    private final ContentManager content;
    private final QuestJournal journal;
    private final DialogueManager dialogues;
    private final PartyManager parties;
    private final QuestlineService questlines;
    private final CutsceneManager cutscenes;
    private final JavaPlugin plugin;
    private final Database db;
    private final CommunityManager community;
    private final MarkerService markers;
    private final SidebarService sidebar;

    public QuestsCommand(JavaPlugin plugin, Database db, QuestService quests, ContentManager content, QuestJournal journal,
                         DialogueManager dialogues, PartyManager parties, QuestlineService questlines, CutsceneManager cutscenes,
                         CommunityManager community, MarkerService markers, SidebarService sidebar) {
        this.plugin = plugin;
        this.db = db;
        this.community = community;
        this.markers = markers;
        this.sidebar = sidebar;
        this.quests = quests;
        this.content = content;
        this.journal = journal;
        this.dialogues = dialogues;
        this.parties = parties;
        this.questlines = questlines;
        this.cutscenes = cutscenes;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }
        if (!p.hasPermission("desquests.use")) {
            p.sendMessage(Messages.get("cmd.nopermission"));
            return true;
        }
        String sub = args.length == 0 ? "journal" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "journal" -> journal.open(p, QuestJournal.Tab.ACTIVE, 0);
            case "active" -> journal.open(p, QuestJournal.Tab.ACTIVE, 0);
            case "available" -> journal.open(p, QuestJournal.Tab.AVAILABLE, 0);
            case "completed" -> journal.open(p, QuestJournal.Tab.COMPLETED, 0);
            case "track", "untrack" -> {
                if (args.length < 2) {
                    p.sendMessage(Component.text("Usage: /" + label + " " + sub + " <quest>", NamedTextColor.RED));
                    return true;
                }
                boolean ok = quests.setTracked(p, args[1], sub.equals("track"));
                p.sendMessage(ok ? Messages.get(sub.equals("track") ? "cmd.track.on" : "cmd.track.off", "quest", title(args[1]))
                        : Messages.get("cmd.track.missing", "quest", args[1]));
            }
            case "abandon" -> {
                if (args.length < 2) {
                    p.sendMessage(Component.text("Usage: /" + label + " abandon <quest>", NamedTextColor.RED));
                    return true;
                }
                boolean ok = quests.abandon(p, args[1]);
                p.sendMessage(ok ? Messages.get("cmd.abandon.done", "quest", title(args[1]))
                        : Messages.get("cmd.track.missing", "quest", args[1]));
            }
            case "dialogue" -> {
                if (args.length >= 2 && args[1].equalsIgnoreCase("next")) {
                    dialogues.next(p);
                } else if (args.length >= 3 && args[1].equalsIgnoreCase("choose")) {
                    try {
                        dialogues.choose(p, Integer.parseInt(args[2]));
                    } catch (NumberFormatException e) {
                        p.sendMessage(Messages.get("dialogue.invalid"));
                    }
                }
            }
            case "questlines" -> {
                List<Component> lines = questlines.describe(p);
                if (lines.isEmpty()) p.sendMessage(Messages.get("cmd.questlines.none"));
                lines.forEach(p::sendMessage);
            }
            case "achievements" -> {
                PlayerState st = quests.state(p);
                if (st == null) {
                    p.sendMessage(Messages.get("quest.loading"));
                    return true;
                }
                if (content.achievements().isEmpty()) p.sendMessage(Messages.get("cmd.achievements.none"));
                content.achievements().values().forEach(a -> {
                    boolean has = st.flags.contains("ach:" + a.id());
                    if (a.hidden() && !has) return;
                    p.sendMessage(Component.text((has ? "[x] " : "[ ] ") + a.title() + (a.description().isBlank() ? "" : " - " + a.description()),
                            has ? NamedTextColor.GREEN : NamedTextColor.GRAY));
                });
            }
            case "reputation" -> {
                PlayerState st = quests.state(p);
                if (st == null || st.counters.isEmpty()) {
                    p.sendMessage(Messages.get("cmd.reputation.none"));
                    return true;
                }
                st.counters.entrySet().stream().sorted(java.util.Map.Entry.comparingByKey())
                        .forEach(en -> p.sendMessage(Component.text(en.getKey() + ": " + en.getValue(), NamedTextColor.YELLOW)));
            }
            case "community" -> {
                List<Component> lines = community.describe();
                if (lines.isEmpty()) p.sendMessage(Messages.get("cmd.community.none"));
                lines.forEach(p::sendMessage);
            }
            case "recommend" -> {
                PlayerState st = quests.state(p);
                List<QuestDefinition> rec = st == null ? List.of() : quests.recommend(st, 3);
                if (rec.isEmpty()) p.sendMessage(Messages.get("cmd.recommend.none"));
                for (QuestDefinition q : rec) {
                    p.sendMessage(Messages.get("cmd.recommend.entry", "title", q.title(), "description", q.description()
                            + (q.giver().isBlank() ? "" : " " + Messages.plain("cmd.recommend.ask", "giver", q.giver()))));
                }
            }
            case "top" -> {
                if (args.length < 2 || !content.quests().containsKey(args[1])) {
                    p.sendMessage(Component.text("Usage: /" + label + " top <quest>", NamedTextColor.RED));
                    return true;
                }
                String qid = args[1];
                db.topCompletions(qid, 10).whenComplete((rows, err) -> {
                    if (!plugin.isEnabled()) return;
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (err != null) {
                            plugin.getLogger().severe("Leaderboard query failed: " + err);
                            p.sendMessage(Messages.get("cmd.top.failed"));
                            return;
                        }
                        p.sendMessage(Messages.get("cmd.top.title", "quest", title(qid)));
                        int rank = 1;
                        for (Database.TopEntry row : rows) {
                            String name = Bukkit.getOfflinePlayer(row.player()).getName();
                            p.sendMessage(Component.text(rank++ + ". " + (name == null ? row.player().toString() : name) + " - " + row.count(), NamedTextColor.YELLOW));
                        }
                        if (rows.isEmpty()) p.sendMessage(Messages.get("cmd.top.empty"));
                    });
                });
            }
            case "markers", "sidebar" -> {
                boolean on = args.length >= 2 && args[1].equalsIgnoreCase("on");
                boolean off = args.length >= 2 && args[1].equalsIgnoreCase("off");
                if (!on && !off) {
                    p.sendMessage(Component.text("Usage: /" + label + " " + sub + " on|off", NamedTextColor.RED));
                    return true;
                }
                if (sub.equals("markers")) {
                    if (on) quests.removeFlag(p, "pref:nomarkers"); else quests.addFlag(p, "pref:nomarkers");
                    markers.update(p, true);
                } else {
                    if (on) quests.addFlag(p, "pref:sidebar"); else quests.removeFlag(p, "pref:sidebar");
                    sidebar.update(p);
                }
                p.sendMessage(Component.text(sub + " " + (on ? "on" : "off"), NamedTextColor.GREEN));
            }
            case "skip" -> {
                if (!cutscenes.skip(p)) p.sendMessage(Messages.get("cmd.skip.none"));
            }
            case "party" -> party(p, label, args);
            case "help" -> {
                for (int i = 1; i <= 9; i++) p.sendMessage(Messages.get("help." + i));
            }
            default -> p.sendMessage(Messages.get("cmd.unknown", "label", label));
        }
        return true;
    }

    private void party(Player p, String label, String[] args) {
        String sub = args.length < 2 ? "list" : args[1].toLowerCase(Locale.ROOT);
        String err;
        switch (sub) {
            case "create" -> err = parties.create(p.getUniqueId());
            case "leave" -> err = parties.leave(p.getUniqueId());
            case "accept" -> err = parties.accept(p.getUniqueId(), System.currentTimeMillis());
            case "invite" -> {
                Player t = args.length < 3 ? null : Bukkit.getPlayerExact(args[2]);
                if (t == null) {
                    p.sendMessage(Component.text("Usage: /" + label + " party invite <online player>", NamedTextColor.RED));
                    return;
                }
                err = parties.invite(p.getUniqueId(), t.getUniqueId(), System.currentTimeMillis());
                if (err == null) {
                    t.sendMessage(Component.text(p.getName() + " invited you to a party. Type /" + label + " party accept (60s).", NamedTextColor.GOLD));
                    p.sendMessage(Component.text("Invited " + t.getName() + ".", NamedTextColor.GREEN));
                    return;
                }
            }
            case "list" -> {
                StringBuilder sb = new StringBuilder();
                for (java.util.UUID u : parties.membersOf(p.getUniqueId())) {
                    Player m = Bukkit.getPlayer(u);
                    sb.append(m == null ? "(offline)" : m.getName()).append(' ');
                }
                p.sendMessage(Component.text((parties.inParty(p.getUniqueId()) ? "Party: " : "You are not in a party. Members: ") + sb.toString().trim(), NamedTextColor.YELLOW));
                return;
            }
            default -> {
                p.sendMessage(Component.text("Usage: /" + label + " party create|invite <player>|accept|leave|list", NamedTextColor.RED));
                return;
            }
        }
        p.sendMessage(err == null ? Messages.get("cmd.done") : Component.text(err, NamedTextColor.RED));
    }

    private String title(String id) {
        QuestDefinition q = content.quests().get(id);
        return q == null ? id : q.title();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!(sender instanceof Player p)) return List.of();
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) return SUB.stream().filter(s -> s.startsWith(prefix)).toList();
        if (args.length == 2 && args[0].equalsIgnoreCase("party")) {
            return List.of("create", "invite", "accept", "leave", "list").stream().filter(s -> s.startsWith(prefix)).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("party") && args[1].equalsIgnoreCase("invite")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted().toList();
        }
        if (args.length == 2 && List.of("track", "untrack", "abandon").contains(args[0].toLowerCase(Locale.ROOT))) {
            PlayerState s = quests.state(p);
            if (s == null) return List.of();
            return new ArrayList<>(s.active.keySet()).stream().filter(id -> id.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted().toList();
        }
        return List.of();
    }
}
