package net.dragonempire.chronicles.commands;

import net.dragonempire.chronicles.ChroniclesPlugin;
import net.dragonempire.chronicles.npc.NpcDefinition;
import net.dragonempire.chronicles.npc.NpcNames;
import net.dragonempire.chronicles.npc.SkinSpec;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestStatus;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AdminCommand implements CommandExecutor, TabCompleter {
    private static final String USAGE = "/%s <studio|reload|validate|diagnostics|npc|quest|dialogue|progress|cutscene|event|boss|questline>";
    private final ChroniclesPlugin plugin;

    public AdminCommand(ChroniclesPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean deny(CommandSender s, String node) {
        if (s.hasPermission(node) || s.hasPermission("desquests.admin")) return false;
        s.sendMessage("You do not have permission (" + node + ").");
        return true;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            sender.sendMessage("Usage: " + USAGE.formatted(label));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                if (deny(sender, "desquests.reload")) return true;
                plugin.reloadConfig();
                report(sender, plugin.reloadContent());
            }
            case "validate" -> {
                if (deny(sender, "desquests.quest.edit")) return true;
                report(sender, plugin.reloadContent());
            }
            case "diagnostics" -> {
                if (deny(sender, "desquests.debug")) return true;
                long published = plugin.content().quests().values().stream().filter(q -> q.status() == QuestStatus.PUBLISHED).count();
                sender.sendMessage("Quests: " + plugin.content().quests().size() + " (" + published + " published)");
                sender.sendMessage("Dialogues: " + plugin.content().dialogues().size() + ", locations: " + plugin.content().locations().size()
                        + ", NPCs: " + plugin.npcs().all().size() + ", questlines: " + plugin.content().questlines().size()
                        + ", events: " + plugin.content().events().size() + ", cutscenes: " + plugin.content().cutscenes().size()
                        + ", bosses: " + plugin.content().bosses().size());
                sender.sendMessage("Validation issues: " + plugin.content().issues().size());
                plugin.database().schemaVersion().whenComplete((v, err) ->
                        plugin.getServer().getScheduler().runTask(plugin, () -> sender.sendMessage(
                                err == null ? "Database schema version: " + v : "Database error: " + err.getMessage())));
            }
            case "studio" -> {
                if (deny(sender, "desquests.quest.edit")) return true;
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("The studio is an in-game menu.");
                    return true;
                }
                plugin.studioMenu().open(p, net.dragonempire.chronicles.studio.StudioMenu.Kind.MAIN, 0);
            }
            case "cutscene" -> cutscene(sender, label, a);
            case "dialogue" -> dialogue(sender, label, a);
            case "event" -> event(sender, label, a);
            case "boss" -> boss(sender, label, a);
            case "questline" -> {
                if (deny(sender, "desquests.questline.manage")) return true;
                if (plugin.content().questlines().isEmpty()) sender.sendMessage("No questlines.");
                plugin.content().questlines().values().forEach(l -> sender.sendMessage(l.id() + " - " + l.title() + " (" + l.chapters().size() + " chapters)"));
            }
            case "npc" -> npc(sender, label, a);
            case "quest" -> quest(sender, label, a);
            case "progress" -> {
                if (deny(sender, "desquests.progress.manage")) return true;
                Player t = a.length < 2 ? null : Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    sender.sendMessage("Usage: /" + label + " progress <online player>");
                    return true;
                }
                PlayerState s = plugin.quests().state(t);
                if (s == null) {
                    sender.sendMessage("That player's data is not loaded.");
                    return true;
                }
                sender.sendMessage(t.getName() + " - active: " + String.join(", ", s.active.keySet()));
                sender.sendMessage("completed: " + s.completions);
            }
            default -> sender.sendMessage("Unknown subcommand. Usage: " + USAGE.formatted(label));
        }
        return true;
    }

    private void npc(CommandSender sender, String label, String[] a) {
        if (a.length < 2) {
            sender.sendMessage("Usage: /" + label + " npc <create|rename|setskin|showname|move|dialogue|delete|list|talk> ...");
            return;
        }
        String sub = a[1].toLowerCase(Locale.ROOT);
        // NPC ids are case-insensitive for convenience; they are stored lowercase.
        String id = a.length >= 3 ? NpcNames.normalizeId(a[2]) : "";
        switch (sub) {
            case "list" -> {
                if (deny(sender, "desquests.npc.edit")) return;
                if (plugin.npcs().all().isEmpty()) sender.sendMessage("No NPCs.");
                for (NpcDefinition d : plugin.npcs().all()) {
                    sender.sendMessage(d.id() + " (" + net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                            .serialize(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(d.name())) + ") - "
                            + d.world() + " " + (int) d.x() + " " + (int) d.y() + " " + (int) d.z()
                            + (d.dialogue().isBlank() ? "" : " dialogue=" + d.dialogue()) + (d.skin() != null ? " [skin]" : "") + (d.showName() ? "" : " [name hidden]"));
                }
            }
            case "create", "move" -> {
                if (deny(sender, sub.equals("create") ? "desquests.npc.create" : "desquests.npc.edit")) return;
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Run this in-game: it uses your position.");
                    return;
                }
                if (a.length < 3) {
                    sender.sendMessage(sub.equals("create")
                            ? "Usage: /" + label + " npc create <id> [display name...]   e.g. npc create ancient_one Ancient One"
                            : "Usage: /" + label + " npc move <id>");
                    return;
                }
                String err;
                if (sub.equals("create")) {
                    String display = a.length >= 4 ? String.join(" ", java.util.Arrays.copyOfRange(a, 3, a.length)) : NpcNames.prettify(id);
                    err = plugin.npcs().create(id, p.getLocation(), display);
                } else {
                    err = plugin.npcs().move(id, p.getLocation());
                }
                sender.sendMessage(err == null ? "Done: " + id : err);
            }
            case "rename" -> {
                if (deny(sender, "desquests.npc.edit")) return;
                if (a.length < 4) {
                    sender.sendMessage("Usage: /" + label + " npc rename <id> <display name...>   (MiniMessage allowed, e.g. <gold>Ancient One)");
                    return;
                }
                String err = plugin.npcs().rename(id, String.join(" ", java.util.Arrays.copyOfRange(a, 3, a.length)));
                sender.sendMessage(err == null ? id + " is now shown as: " + String.join(" ", java.util.Arrays.copyOfRange(a, 3, a.length)) : err);
            }
            case "showname" -> {
                if (deny(sender, "desquests.npc.edit")) return;
                if (a.length < 4 || !(a[3].equalsIgnoreCase("true") || a[3].equalsIgnoreCase("false"))) {
                    sender.sendMessage("Usage: /" + label + " npc showname <id> <true|false>   (false hides the floating name, for secret NPCs)");
                    return;
                }
                String err = plugin.npcs().setShowName(id, Boolean.parseBoolean(a[3]));
                sender.sendMessage(err == null ? id + (Boolean.parseBoolean(a[3]) ? " now shows" : " now hides") + " its name." : err);
            }
            case "setskin" -> {
                if (deny(sender, "desquests.npc.edit")) return;
                String usage = "Usage: /" + label + " npc setskin <id> <PlayerName> | texture <value> [signature] | none";
                if (a.length < 4) { sender.sendMessage(usage); return; }
                java.util.List<net.dragonempire.chronicles.validation.ValidationIssue> issues = new java.util.ArrayList<>();
                SkinSpec skin;
                if (a[3].equalsIgnoreCase("none")) {
                    skin = null;
                } else if (a[3].equalsIgnoreCase("texture")) {
                    if (a.length < 5) { sender.sendMessage(usage); return; }
                    java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
                    m.put("value", a[4]);
                    if (a.length >= 6) m.put("signature", a[5]);
                    skin = SkinSpec.parse(m, "command", "skin", issues);
                } else {
                    skin = SkinSpec.parse(java.util.Map.of("player", a[3]), "command", "skin", issues);
                }
                if (!issues.isEmpty()) {
                    sender.sendMessage("Invalid skin: " + issues.get(0).message());
                    return;
                }
                String err = plugin.npcs().setSkin(id, skin);
                sender.sendMessage(err == null ? (skin == null ? "Skin cleared for " + id : id + " now uses a custom skin (it is a Mannequin NPC).") : err);
            }
            case "talk" -> {
                if (deny(sender, "desquests.npc.edit")) return;
                Player t = a.length < 4 ? null : Bukkit.getPlayerExact(a[3]);
                if (t == null) {
                    sender.sendMessage("Usage: /" + label + " npc talk <id> <online player>");
                    return;
                }
                String err = plugin.npcs().talk(t, id);
                if (err != null) sender.sendMessage(err);
            }
            case "delete" -> {
                if (deny(sender, "desquests.npc.create")) return;
                if (a.length < 3) {
                    sender.sendMessage("Usage: /" + label + " npc delete <id>");
                    return;
                }
                String err = plugin.npcs().delete(id);
                sender.sendMessage(err == null ? "Deleted " + id : err);
            }
            case "dialogue" -> {
                if (deny(sender, "desquests.dialogue.manage")) return;
                if (a.length < 4) {
                    sender.sendMessage("Usage: /" + label + " npc dialogue <id> <dialogueId>");
                    return;
                }
                String err = plugin.npcs().setDialogue(id, a[3]);
                sender.sendMessage(err == null ? id + " now uses dialogue " + a[3] : err);
            }
            default -> sender.sendMessage("Usage: /" + label + " npc <create|rename|setskin|showname|move|dialogue|delete|list|talk> ...");
        }
    }

    private void dialogue(CommandSender sender, String label, String[] a) {
        if (deny(sender, "desquests.dialogue.manage")) return;
        String sub = a.length < 2 ? "" : a[1].toLowerCase(Locale.ROOT);
        var ed = plugin.dialogueEditor();
        String err;
        switch (sub) {
            case "create" -> {
                if (a.length < 3) { sender.sendMessage("Usage: /" + label + " dialogue create <id>"); return; }
                err = ed.create(a[2]);
            }
            case "speaker" -> {
                if (a.length < 4) { sender.sendMessage("Usage: /" + label + " dialogue speaker <id> <name> [#hexcolor]  (use _ for spaces in the name)"); return; }
                err = ed.setSpeaker(a[2], a[3].replace('_', ' '), a.length >= 5 ? a[4] : null);
            }
            case "addnode" -> {
                if (a.length < 5) { sender.sendMessage("Usage: /" + label + " dialogue addnode <id> <node> <text...>"); return; }
                err = ed.addNode(a[2], a[3], String.join(" ", java.util.Arrays.copyOfRange(a, 4, a.length)));
            }
            case "addchoice" -> {
                if (a.length < 7) { sender.sendMessage("Usage: /" + label + " dialogue addchoice <id> <node> <choiceId> <nextNode|end> <text...>"); return; }
                err = ed.addChoice(a[2], a[3], a[4], a[5], String.join(" ", java.util.Arrays.copyOfRange(a, 6, a.length)));
            }
            case "addcondition", "addaction" -> {
                if (a.length < 6) { sender.sendMessage("Usage: /" + label + " dialogue " + sub + " <id> <node> <choiceId> <type> [key=value ...]"); return; }
                err = ed.addToChoice(a[2], a[3], a[4], sub.equals("addcondition") ? "if" : "actions", a[5], java.util.Arrays.asList(a).subList(6, a.length));
            }
            default -> {
                sender.sendMessage("Usage: /" + label + " dialogue <create|speaker|addnode|addchoice|addcondition|addaction> ...");
                return;
            }
        }
        sender.sendMessage(err == null ? "Done. The dialogue was validated after the change." : err);
    }

    private void cutscene(CommandSender sender, String label, String[] a) {
        if (deny(sender, "desquests.cutscene.manage")) return;
        String csub = a.length < 2 ? "" : a[1].toLowerCase(Locale.ROOT);
        if (csub.equals("create") || csub.equals("addstep")) {
            String err;
            if (csub.equals("create")) {
                if (a.length < 3) { sender.sendMessage("Usage: /" + label + " cutscene create <id>"); return; }
                err = plugin.cutsceneEditor().create(a[2]);
            } else {
                if (a.length < 5) { sender.sendMessage("Usage: /" + label + " cutscene addstep <id> <atTick> <type> [key=value ...]"); return; }
                int at;
                try {
                    at = Integer.parseInt(a[3]);
                } catch (NumberFormatException e) {
                    sender.sendMessage("atTick must be a whole number.");
                    return;
                }
                err = plugin.cutsceneEditor().addStep(a[2], at, a[4], java.util.Arrays.asList(a).subList(5, a.length));
            }
            sender.sendMessage(err == null ? "Done. The cutscene was validated after the change." : err);
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("play")) {
            sender.sendMessage("Usage: /" + label + " cutscene <play <id> [player] | create <id> | addstep <id> <atTick> <type> [key=value ...]>");
            return;
        }
        Player t = a.length >= 4 ? Bukkit.getPlayerExact(a[3]) : sender instanceof Player p ? p : null;
        if (t == null) {
            sender.sendMessage("Specify an online player.");
            return;
        }
        String err = plugin.cutscenes().play(a[2], t);
        sender.sendMessage(err == null ? "Playing " + a[2] + " for " + t.getName() : err);
    }

    private void event(CommandSender sender, String label, String[] a) {
        if (deny(sender, "desquests.event.manage")) return;
        String sub = a.length < 2 ? "" : a[1].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            if (plugin.content().events().isEmpty()) sender.sendMessage("No events.");
            plugin.content().events().values().forEach(e -> sender.sendMessage(e.id() + " - " + e.title() + (plugin.events().isActive(e.id()) ? " [ACTIVE]" : " [inactive]")));
            return;
        }
        if ((!sub.equals("start") && !sub.equals("stop")) || a.length < 3) {
            sender.sendMessage("Usage: /" + label + " event <start|stop|list> [id]");
            return;
        }
        String err = plugin.events().set(a[2], sub.equals("start"));
        sender.sendMessage(err == null ? "Event " + a[2] + (sub.equals("start") ? " started." : " stopped.") : err);
    }

    private void boss(CommandSender sender, String label, String[] a) {
        if (deny(sender, "desquests.boss.manage")) return;
        if (a.length >= 4 && a[1].equalsIgnoreCase("credit")) {
            Player t = Bukkit.getPlayerExact(a[3]);
            String err = t == null ? "Player not online: " + a[3] : plugin.bosses().credit(t, a[2]);
            sender.sendMessage(err == null ? "Credited " + t.getName() + " with defeating " + a[2] : err);
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("spawn")) {
            sender.sendMessage("Usage: /" + label + " boss <spawn <id> | credit <id> <player>>");
            return;
        }
        String err = plugin.bosses().spawn(a[2], sender instanceof Player p ? p : null);
        sender.sendMessage(err == null ? "Spawned boss " + a[2] + " at its configured location." : err);
    }

    private void editQuest(CommandSender sender, String label, String sub, String[] a) {
        String node = sub.equals("create") ? "desquests.quest.create" : sub.equals("delete") ? "desquests.quest.delete" : "desquests.quest.edit";
        if (deny(sender, node)) return;
        var editor = plugin.questEditor();
        String err;
        switch (sub) {
            case "create" -> {
                if (a.length < 3) { sender.sendMessage("Usage: /" + label + " quest create <id>"); return; }
                err = editor.create(a[2]);
            }
            case "set" -> {
                if (a.length < 5) { sender.sendMessage("Usage: /" + label + " quest set <id> <key> <value...>"); return; }
                err = editor.set(a[2], a[3].toLowerCase(Locale.ROOT), String.join(" ", java.util.Arrays.copyOfRange(a, 4, a.length)));
            }
            case "addobjective" -> {
                if (a.length < 6) { sender.sendMessage("Usage: /" + label + " quest addobjective <id> <TYPE> <target|-> <amount> [stage=N]"); return; }
                int amount;
                int stage = 0;
                try {
                    amount = Integer.parseInt(a[5]);
                    if (a.length >= 7 && a[6].toLowerCase(Locale.ROOT).startsWith("stage=")) stage = Integer.parseInt(a[6].substring(6));
                } catch (NumberFormatException e) {
                    sender.sendMessage("Amount and stage must be whole numbers.");
                    return;
                }
                err = editor.addObjective(a[2], a[3], a[4], amount, stage);
            }
            case "addstage" -> {
                if (a.length < 7) { sender.sendMessage("Usage: /" + label + " quest addstage <id> <sequential|parallel> <TYPE> <target|-> <amount>"); return; }
                int amount;
                try {
                    amount = Integer.parseInt(a[6]);
                } catch (NumberFormatException e) {
                    sender.sendMessage("Amount must be a whole number.");
                    return;
                }
                err = editor.addStage(a[2], a[3], a[4], a[5], amount);
            }
            case "addreward" -> {
                if (a.length < 4) { sender.sendMessage("Usage: /" + label + " quest addreward <id> <type> [key=value ...]"); return; }
                err = editor.addReward(a[2], a[3], java.util.Arrays.asList(a).subList(4, a.length));
            }
            default -> {
                if (a.length < 3) { sender.sendMessage("Usage: /" + label + " quest delete <id> [confirm]"); return; }
                err = editor.delete(a[2], a.length >= 4 && a[3].equalsIgnoreCase("confirm"));
            }
        }
        sender.sendMessage(err == null ? "Done. The quest was validated after the change." : err);
    }

    private void quest(CommandSender sender, String label, String[] a) {
        String qsub = a.length < 2 ? "" : a[1].toLowerCase(Locale.ROOT);
        if (List.of("create", "set", "addobjective", "addstage", "addreward", "delete").contains(qsub)) {
            editQuest(sender, label, qsub, a);
            return;
        }
        if (List.of("publish", "disable", "draft", "validate").contains(qsub)) {
            if (deny(sender, qsub.equals("validate") ? "desquests.quest.edit" : "desquests.quest.publish")) return;
            if (a.length < 3) {
                sender.sendMessage("Usage: /" + label + " quest " + qsub + " <questId>");
                return;
            }
            if (qsub.equals("validate")) {
                List<ValidationIssue> issues = plugin.reloadContent();
                String file = plugin.content().questFiles().get(a[2]);
                if (file == null) {
                    sender.sendMessage("Quest '" + a[2] + "' did not load. Problems:");
                    issues.stream().limit(10).forEach(i -> sender.sendMessage(" - " + i));
                } else {
                    long mine = issues.stream().filter(i -> i.file().equals(file)).count();
                    sender.sendMessage(mine == 0 ? "Quest '" + a[2] + "' is valid (" + file + ")." : mine + " problem(s) in " + file);
                    issues.stream().filter(i -> i.file().equals(file)).forEach(i -> sender.sendMessage(" - " + i));
                }
                return;
            }
            QuestStatus target = qsub.equals("publish") ? QuestStatus.PUBLISHED : qsub.equals("disable") ? QuestStatus.DISABLED : QuestStatus.DRAFT;
            String err = plugin.studio().setQuestStatus(a[2], target);
            sender.sendMessage(err == null ? a[2] + " is now " + target.name().toLowerCase(Locale.ROOT) + "." : err);
            return;
        }
        if (a.length < 4 || !List.of("give", "complete", "reset").contains(a[1].toLowerCase(Locale.ROOT))) {
            sender.sendMessage("Usage: /" + label + " quest <give|complete|reset> <player> <id> | quest <publish|disable|draft|validate|delete> <id> | quest <create|set|addobjective|addreward> ...");
            return;
        }
        if (deny(sender, "desquests.progress.manage")) return;
        Player t = Bukkit.getPlayerExact(a[2]);
        if (t == null) {
            sender.sendMessage("Player not online: " + a[2]);
            return;
        }
        QuestDefinition q = plugin.content().quests().get(a[3]);
        if (q == null) {
            sender.sendMessage("Unknown quest: " + a[3]);
            return;
        }
        switch (a[1].toLowerCase(Locale.ROOT)) {
            case "give" -> {
                String err = plugin.quests().start(t, q.id(), true);
                sender.sendMessage(err == null ? "Gave " + q.id() + " to " + t.getName() : err);
            }
            case "complete" -> {
                PlayerState s = plugin.quests().state(t);
                if (s == null) {
                    sender.sendMessage("That player's data is not loaded.");
                    return;
                }
                if (!s.active.containsKey(q.id())) {
                    String err = plugin.quests().start(t, q.id(), true);
                    if (err != null) {
                        sender.sendMessage(err);
                        return;
                    }
                }
                plugin.quests().complete(t, q.id());
                sender.sendMessage("Completed " + q.id() + " for " + t.getName());
            }
            case "reset" -> {
                plugin.quests().reset(t, q.id());
                sender.sendMessage("Reset " + q.id() + " for " + t.getName() + " (progress, completion and reward claims cleared).");
            }
            default -> { }
        }
    }

    private void report(CommandSender sender, List<ValidationIssue> issues) {
        sender.sendMessage("Loaded " + plugin.content().quests().size() + " quest(s), " + plugin.content().dialogues().size()
                + " dialogue(s), " + plugin.npcs().all().size() + " NPC(s); " + issues.size() + " issue(s).");
        for (ValidationIssue i : issues) sender.sendMessage(" - " + i);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] a) {
        String p = a[a.length - 1].toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if (a.length == 1) out.addAll(List.of("studio", "reload", "validate", "diagnostics", "npc", "quest", "dialogue", "progress", "cutscene", "event", "boss", "questline"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("dialogue")) out.addAll(List.of("create", "speaker", "addnode", "addchoice", "addcondition", "addaction"));
        else if (a.length == 3 && a[0].equalsIgnoreCase("dialogue") && !a[1].equalsIgnoreCase("create")) out.addAll(plugin.content().dialogues().keySet());
        else if (a.length == 2 && a[0].equalsIgnoreCase("cutscene")) out.addAll(List.of("play", "create", "addstep"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("event")) out.addAll(List.of("start", "stop", "list"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("boss")) out.addAll(List.of("spawn", "credit"));
        else if (a.length == 3 && a[0].equalsIgnoreCase("cutscene") && !a[1].equalsIgnoreCase("create")) out.addAll(plugin.content().cutscenes().keySet());
        else if (a.length == 3 && a[0].equalsIgnoreCase("event")) out.addAll(plugin.content().events().keySet());
        else if (a.length == 3 && a[0].equalsIgnoreCase("boss")) out.addAll(plugin.content().bosses().keySet());
        else if (a.length == 2 && a[0].equalsIgnoreCase("npc")) out.addAll(List.of("create", "rename", "setskin", "showname", "delete", "list", "move", "dialogue", "talk"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("quest")) out.addAll(List.of("give", "complete", "reset", "publish", "disable", "draft", "validate", "create", "set", "addobjective", "addstage", "addreward", "delete"));
        else if (a.length == 3 && a[0].equalsIgnoreCase("npc") && !a[1].equalsIgnoreCase("create") && !a[1].equalsIgnoreCase("list")) {
            plugin.npcs().all().forEach(d -> out.add(d.id()));
        } else if (a.length == 4 && a[0].equalsIgnoreCase("npc") && a[1].equalsIgnoreCase("dialogue")) {
            out.addAll(plugin.content().dialogues().keySet());
        } else if (a.length == 3 && a[0].equalsIgnoreCase("quest") && List.of("publish", "disable", "draft", "validate", "set", "addobjective", "addstage", "addreward", "delete").contains(a[1].toLowerCase(Locale.ROOT))) {
            out.addAll(plugin.content().quests().keySet());
        } else if (a.length == 3 && (a[0].equalsIgnoreCase("quest") || a[0].equalsIgnoreCase("progress"))) {
            Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
        } else if (a.length == 4 && a[0].equalsIgnoreCase("quest")) {
            out.addAll(plugin.content().quests().keySet());
        }
        return out.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(p)).sorted().toList();
    }
}
