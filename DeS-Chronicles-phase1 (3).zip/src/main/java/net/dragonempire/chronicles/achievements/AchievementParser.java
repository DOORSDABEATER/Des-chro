package net.dragonempire.chronicles.achievements;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class AchievementParser {
    private AchievementParser() {}

    /** root is the parsed achievements.yml; entries live under "achievements". */
    public static Map<String, AchievementDefinition> parse(Map<String, Object> root, String file, List<ValidationIssue> issues) {
        Map<String, AchievementDefinition> out = new LinkedHashMap<>();
        if (!(root.get("achievements") instanceof Map<?, ?> m)) return out;
        for (Map.Entry<?, ?> e : m.entrySet()) {
            String id = String.valueOf(e.getKey());
            String p = "achievements." + id;
            if (!id.matches("[a-z0-9_]{2,40}")) {
                issues.add(new ValidationIssue(file, p, "id must match [a-z0-9_]{2,40}"));
                continue;
            }
            if (!(e.getValue() instanceof Map<?, ?> v) || !(v.get("title") instanceof String title) || title.isBlank()) {
                issues.add(new ValidationIssue(file, p + ".title", "required"));
                continue;
            }
            out.put(id, new AchievementDefinition(id, title, v.get("description") instanceof String d ? d : "", Boolean.TRUE.equals(v.get("hidden"))));
        }
        return out;
    }
}
