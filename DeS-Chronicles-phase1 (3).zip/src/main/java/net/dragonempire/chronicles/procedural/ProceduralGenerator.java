package net.dragonempire.chronicles.procedural;

import net.dragonempire.chronicles.quest.ResetPolicy;
import net.dragonempire.chronicles.validation.ValidationIssue;

import java.time.Instant;
import java.time.ZoneId;
import java.util.*;

/**
 * Builds rotating quests from a template. The choice of objective, target and amount is a deterministic function of
 * (template id, period), so every player and every restart sees the same quest for the same day or week.
 * Tiers produce one quest per level band, which is how difficulty scales with the player's level.
 * The output is an ordinary quest document that goes through the normal quest parser.
 *
 * Template keys: rotation (daily|weekly), title, description (placeholders {target} {amount}), category, giver,
 * event, party, party_distance, rewards, pool [{type, target | targets, amount | {min, max}, description}],
 * tiers [{min_level, max_level, multiplier, rewards}].
 */
public final class ProceduralGenerator {
    private ProceduralGenerator() {}

    public static String periodKey(String rotation, Instant now, ZoneId zone) {
        return ResetPolicy.periodStart(rotation, now, zone).atZone(zone).toLocalDate().toString().replace("-", "");
    }

    /** Returns an empty list (after adding issues) if the template is invalid. */
    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> generate(String templateId, Map<String, Object> t, String periodKey, String file,
                                                     List<ValidationIssue> issues) {
        int before = issues.size();
        String rotation = String.valueOf(t.getOrDefault("rotation", "daily")).toLowerCase(Locale.ROOT);
        if (!rotation.equals("daily") && !rotation.equals("weekly")) issues.add(new ValidationIssue(file, "rotation", "must be daily or weekly"));
        if (!(t.get("title") instanceof String title) || title.isBlank()) {
            issues.add(new ValidationIssue(file, "title", "required"));
            return List.of();
        }
        if (!(t.get("pool") instanceof List<?> pool) || pool.isEmpty()) {
            issues.add(new ValidationIssue(file, "pool", "at least one pool entry required"));
            return List.of();
        }
        for (int i = 0; i < pool.size(); i++) {
            String p = "pool[" + i + "]";
            if (!(pool.get(i) instanceof Map<?, ?> m) || !(m.get("type") instanceof String type) || !type.matches("[A-Za-z_]{2,40}")) {
                issues.add(new ValidationIssue(file, p + ".type", "required, like KILL_MOB"));
                continue;
            }
            if (m.get("targets") != null && !(m.get("targets") instanceof List<?> l && !l.isEmpty())) issues.add(new ValidationIssue(file, p + ".targets", "must be a non-empty list"));
            int[] range = range(m.get("amount"));
            if (range == null) issues.add(new ValidationIssue(file, p + ".amount", "needs a number or {min, max} with 1 <= min <= max"));
        }
        List<Map<String, Object>> tiers = new ArrayList<>();
        if (t.get("tiers") instanceof List<?> tl) {
            for (int i = 0; i < tl.size(); i++) {
                String p = "tiers[" + i + "]";
                if (!(tl.get(i) instanceof Map<?, ?> m)) {
                    issues.add(new ValidationIssue(file, p, "must be a map"));
                    continue;
                }
                double mult = m.get("multiplier") instanceof Number n ? n.doubleValue() : 1.0;
                if (mult <= 0 || mult > 100) issues.add(new ValidationIssue(file, p + ".multiplier", "must be in (0, 100]"));
                tiers.add((Map<String, Object>) m);
            }
        }
        if (issues.size() > before) return List.of();
        if (tiers.isEmpty()) tiers.add(Map.of());

        Random random = new Random((templateId + "|" + periodKey).hashCode() * 31L + 17);
        Map<?, ?> chosen = (Map<?, ?>) pool.get(random.nextInt(pool.size()));
        String type = String.valueOf(chosen.get("type")).toUpperCase(Locale.ROOT);
        String target = null;
        if (chosen.get("targets") instanceof List<?> targets) target = String.valueOf(targets.get(random.nextInt(targets.size())));
        else if (chosen.get("target") instanceof String s) target = s;
        int[] range = range(chosen.get("amount"));
        int base = range[0] + (range[1] > range[0] ? random.nextInt(range[1] - range[0] + 1) : 0);

        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = 0; i < tiers.size(); i++) {
            Map<String, Object> tier = tiers.get(i);
            double mult = tier.get("multiplier") instanceof Number n ? n.doubleValue() : 1.0;
            int amount = Math.max(1, (int) Math.round(base * mult));
            String pretty = target == null ? "" : target.toLowerCase(Locale.ROOT).replace('_', ' ');

            Map<String, Object> objective = new LinkedHashMap<>();
            objective.put("id", "o1");
            objective.put("type", type);
            if (target != null) objective.put("target", target);
            objective.put("amount", amount);
            objective.put("description", chosen.get("description") instanceof String d ? fill(d, pretty, amount) : type.toLowerCase(Locale.ROOT).replace('_', ' ') + " " + pretty);

            Map<String, Object> q = new LinkedHashMap<>();
            q.put("id", "proc_" + templateId + "_" + periodKey + (tiers.size() > 1 ? "_t" + (i + 1) : ""));
            q.put("title", fill(title, pretty, amount));
            q.put("description", t.get("description") instanceof String d ? fill(d, pretty, amount) : "");
            q.put("status", "published");
            q.put("category", t.getOrDefault("category", "daily"));
            for (String passthrough : List.of("giver", "event", "party", "party_distance")) if (t.containsKey(passthrough)) q.put(passthrough, t.get(passthrough));
            q.put("required_level", tier.getOrDefault("min_level", 0));
            q.put("max_level", tier.getOrDefault("max_level", 0));
            q.put("objectives", List.of(objective));
            Object rewards = tier.containsKey("rewards") ? tier.get("rewards") : t.get("rewards");
            if (rewards != null) q.put("rewards", rewards);
            out.add(q);
        }
        return out;
    }

    private static String fill(String s, String target, int amount) {
        return s.replace("{target}", target).replace("{amount}", String.valueOf(amount));
    }

    /** {min,max} or a plain number; null if invalid. */
    private static int[] range(Object o) {
        if (o instanceof Number n && n.intValue() >= 1) return new int[]{n.intValue(), n.intValue()};
        if (o instanceof Map<?, ?> m && m.get("min") instanceof Number lo && m.get("max") instanceof Number hi
                && lo.intValue() >= 1 && hi.intValue() >= lo.intValue()) {
            return new int[]{lo.intValue(), hi.intValue()};
        }
        return null;
    }
}
