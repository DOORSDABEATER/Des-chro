package net.dragonempire.chronicles.interactions;

import java.util.List;

/** Interactables must be activated in this exact order. */
public record PuzzleDefinition(String id, List<String> steps) {}
