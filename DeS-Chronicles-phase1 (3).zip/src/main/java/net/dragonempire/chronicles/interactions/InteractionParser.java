package net.dragonempire.chronicles.interactions;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class InteractionParser {
    public record Result(Map<String, InteractableDefinition> interactables, Map<String, PuzzleDefinition> puzzles) {}

    private InteractionParser() {}

    public static Result parse(Map<String, Object> root, String file, List<ValidationIssue> issues) {
        Map<String, InteractableDefinition> items = new LinkedHashMap<>();
        Set<String> positions = new HashSet<>();
        Set<String> declared = new HashSet<>();
        if (root.get("interactables") instanceof Map<?, ?> m) {
            for (Map.Entry<?, ?> e : m.entrySet()) {
                String id = String.valueOf(e.getKey());
                String p = "interactables." + id;
                if (!(e.getValue() instanceof Map<?, ?> v)) {
                    issues.add(new ValidationIssue(file, p, "must be a map"));
                    continue;
                }
                declared.add(id);
                if (Boolean.FALSE.equals(v.get("enabled"))) continue;
                if (!(v.get("world") instanceof String w) || !(v.get("x") instanceof Number x) || !(v.get("y") instanceof Number y)
                        || !(v.get("z") instanceof Number z)) {
                    issues.add(new ValidationIssue(file, p, "needs world, x, y, z"));
                    continue;
                }
                String event = v.get("event") instanceof String s ? s.toUpperCase(Locale.ROOT) : "ACTIVATE_BLOCK";
                if (!event.matches("[A-Z_]{2,40}")) {
                    issues.add(new ValidationIssue(file, p + ".event", "must be an objective type like ACTIVATE_BLOCK or ACTIVATE_RITUAL"));
                    continue;
                }
                InteractableDefinition d = new InteractableDefinition(id, w, x.intValue(), y.intValue(), z.intValue(), event);
                if (!positions.add(d.key())) {
                    issues.add(new ValidationIssue(file, p, "another interactable already uses this block"));
                    continue;
                }
                items.put(id, d);
            }
        }
        Map<String, PuzzleDefinition> puzzles = new LinkedHashMap<>();
        if (root.get("puzzles") instanceof Map<?, ?> m) {
            for (Map.Entry<?, ?> e : m.entrySet()) {
                String id = String.valueOf(e.getKey());
                String p = "puzzles." + id;
                List<String> steps = new ArrayList<>();
                if (e.getValue() instanceof Map<?, ?> v && v.get("steps") instanceof List<?> l) for (Object o : l) steps.add(String.valueOf(o));
                if (steps.size() < 2) {
                    issues.add(new ValidationIssue(file, p + ".steps", "needs at least 2 steps"));
                    continue;
                }
                boolean ok = true;
                for (String st : steps) {
                    if (!declared.contains(st)) {
                        issues.add(new ValidationIssue(file, p + ".steps", "unknown interactable '" + st + "'"));
                        ok = false;
                    }
                }
                if (ok) puzzles.put(id, new PuzzleDefinition(id, List.copyOf(steps)));
            }
        }
        return new Result(items, puzzles);
    }
}
