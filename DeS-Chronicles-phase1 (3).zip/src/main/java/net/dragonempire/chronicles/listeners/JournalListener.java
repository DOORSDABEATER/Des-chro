package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.journal.QuestJournal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** Journal menus are read-only: every click and drag involving them is cancelled. */
public final class JournalListener implements Listener {
    private final QuestJournal journal;

    public JournalListener(QuestJournal journal) {
        this.journal = journal;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof QuestJournal.Holder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;
        if (e.getWhoClicked() instanceof Player p) journal.click(p, h, e.getSlot());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof QuestJournal.Holder) e.setCancelled(true);
    }
}
