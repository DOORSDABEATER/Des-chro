package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.bosses.BossManager;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.persistence.PersistentDataType;

public final class BossListener implements Listener {
    private final BossManager bosses;

    public BossListener(BossManager bosses) {
        this.bosses = bosses;
    }

    private static Player attackerOf(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p) return p;
        if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }

    /** Instanced bosses cannot be damaged by players outside the owning party. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamageCheck(EntityDamageByEntityEvent e) {
        if (!e.getEntity().getPersistentDataContainer().has(bosses.key(), PersistentDataType.STRING)) return;
        Player attacker = attackerOf(e);
        if (attacker != null && !bosses.canDamage(e.getEntity(), attacker)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!e.getEntity().getPersistentDataContainer().has(bosses.key(), PersistentDataType.STRING)) return;
        Player attacker = attackerOf(e);
        if (attacker != null) bosses.onDamage(e.getEntity(), attacker, e.getFinalDamage());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        if (e.getEntity().getPersistentDataContainer().has(bosses.key(), PersistentDataType.STRING)) bosses.onDeath(e.getEntity());
    }
}
