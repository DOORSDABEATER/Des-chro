package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.dialogue.DialogueManager;
import net.dragonempire.chronicles.hud.MarkerService;
import net.dragonempire.chronicles.hud.SidebarService;
import net.dragonempire.chronicles.npc.NpcManager;
import net.dragonempire.chronicles.quest.QuestService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {
    private final QuestService quests;
    private final DialogueManager dialogues;
    private final NpcManager npcs;
    private final MarkerService markers;
    private final SidebarService sidebar;

    public PlayerListener(QuestService quests, DialogueManager dialogues, NpcManager npcs, MarkerService markers, SidebarService sidebar) {
        this.quests = quests;
        this.dialogues = dialogues;
        this.npcs = npcs;
        this.markers = markers;
        this.sidebar = sidebar;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        quests.loadPlayer(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        dialogues.end(e.getPlayer().getUniqueId());
        npcs.forget(e.getPlayer().getUniqueId());
        markers.forget(e.getPlayer());
        sidebar.forget(e.getPlayer().getUniqueId());
        quests.unload(e.getPlayer().getUniqueId());
    }
}
