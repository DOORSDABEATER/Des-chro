package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.content.LocationSpec;
import net.dragonempire.chronicles.hud.MarkerService;
import net.dragonempire.chronicles.objectives.CraftMath;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import net.dragonempire.chronicles.objectives.ObjectiveEvent;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestService;
import org.bukkit.Location;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.FurnaceExtractEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Turns game events into ObjectiveEvents. Everything is event-driven: no repeating tasks.
 * Known limits: crafting counts one result stack per click (shift-click under-counts), and item pickup
 * counts re-picked drops, so COLLECT_ITEM can be farmed by dropping and re-collecting.
 */
public final class ObjectiveListener implements Listener {
    private final QuestService quests;
    private final ContentManager content;
    private final MarkerService markers;
    private final NamespacedKey droppedBy;
    private final java.util.Map<java.util.UUID, Double> travel = new java.util.HashMap<>();

    public ObjectiveListener(JavaPlugin plugin, QuestService quests, ContentManager content, MarkerService markers) {
        this.quests = quests;
        this.content = content;
        this.markers = markers;
        this.droppedBy = new NamespacedKey(plugin, "dropped_by");
    }

    /** Items a player drops are tagged so picking them straight back up cannot be farmed for COLLECT_ITEM. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        e.getItemDrop().getPersistentDataContainer().set(droppedBy, PersistentDataType.STRING, e.getPlayer().getUniqueId().toString());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        quests.onDeath(e.getEntity());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        travel.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent e) {
        Player killer = e.getEntity().getKiller();
        if (killer == null) return;
        quests.handle(killer, new ObjectiveEvent("KILL_MOB", e.getEntity().getType().name()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        LivingEntity who = e.getEntity();
        if (!(who instanceof Player p)) return;
        if (p.getUniqueId().toString().equals(e.getItem().getPersistentDataContainer().get(droppedBy, PersistentDataType.STRING))) return;
        ItemStack stack = e.getItem().getItemStack();
        quests.handle(p, new ObjectiveEvent("COLLECT_ITEM", stack.getType().name(), stack.getAmount()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack result = e.getRecipe().getResult();
        int[] ingredients = new int[0];
        if (e.isShiftClick()) {
            ItemStack[] matrix = e.getInventory().getMatrix();
            ingredients = new int[matrix.length];
            for (int i = 0; i < matrix.length; i++) ingredients[i] = matrix[i] == null ? 0 : matrix[i].getAmount();
        }
        quests.handle(p, new ObjectiveEvent("CRAFT_ITEM", result.getType().name(), CraftMath.produced(e.isShiftClick(), ingredients, result.getAmount())));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSmelt(FurnaceExtractEvent e) {
        if (e.getItemAmount() < 1) return;
        quests.handle(e.getPlayer(), new ObjectiveEvent("SMELT_ITEM", e.getItemType().name(), e.getItemAmount()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_FISH || !(e.getCaught() instanceof Item caught)) return;
        ItemStack stack = caught.getItemStack();
        quests.handle(e.getPlayer(), new ObjectiveEvent("FISH_ITEM", stack.getType().name(), stack.getAmount()));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent e) {
        quests.handle(e.getPlayer(), new ObjectiveEvent("ENTER_WORLD", e.getPlayer().getWorld().getName()));
    }

    /** Only evaluated when the player crosses into a different block, and only against configured locations. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        Location from = e.getFrom();
        if (to == null) return;
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ()) return;
        Player p = e.getPlayer();
        PlayerState s = quests.state(p);
        if (s == null) return;
        markers.update(p, false);
        if (from.getWorld() != null && from.getWorld().equals(to.getWorld()) && quests.wantsEvent(p, "TRAVEL_DISTANCE")) {
            double d = Math.hypot(to.getX() - from.getX(), to.getZ() - from.getZ());
            if (d > 0 && d <= 10) { // larger jumps are teleport-like and ignored
                double acc = travel.merge(p.getUniqueId(), d, Double::sum);
                int whole = (int) acc;
                if (whole >= 1) {
                    travel.put(p.getUniqueId(), acc - whole);
                    quests.handle(p, new ObjectiveEvent("TRAVEL_DISTANCE", "any", whole));
                }
            }
        }
        if (content.locations().isEmpty()) return;
        for (LocationSpec loc : content.locations().values()) {
            if (loc.contains(to) && !loc.contains(from)) {
                if (!s.flags.contains("visited:" + loc.name())) quests.playDiscovery(p); // first time here
                quests.addFlag(p, "visited:" + loc.name());
                quests.handle(p, new ObjectiveEvent("VISIT_LOCATION", loc.name()));
            }
        }
    }
}
